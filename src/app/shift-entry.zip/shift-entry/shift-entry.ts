import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { Server } from '../server';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import iziToast from 'izitoast';
declare var $: any;
type CoinRow = {
  id: number;
  date: string;
  coins: number;   // denomination value
  status: number;
  count?: number;  // user-entered count
};

@Component({
  selector: 'app-shift-entry',
  standalone: true,
  imports: [NgSelectModule, CommonModule, FormsModule],
  templateUrl: './shift-entry.html',
  styleUrls: ['./shift-entry.css']
})

export class ShiftEntry {
  validateFieldsA: boolean = false;
  validateFieldsB: boolean = false;
  coinCollapseVisible: boolean = false;
  cashCollapseVisible: boolean = false;
  evtotalCollapseVisible: boolean = false;
  coinCollapseVisibleB: boolean = false;
  cashCollapseVisibleB: boolean = false;
  evtotalCollapseVisibleB: boolean = false;
  oilCollapseVisible: boolean = false;
  oilCollapseVisibleB: boolean = false;
  creditCollapseVisible: boolean = false;
  creditCollapseVisibleB: boolean = false;
  rpsPriceMessage: any;
  coinstype: any;
  cashtype: any;
  Oiltype: any;
  cashData: any;
  products: any[] = [];
  ev_entry: any[] = [];
  coinData: any[] = [];
  cashList: any[] = [];
  customerOptions: any[] = [];
  customerOptionsB: any[] = [];
  coinGrandTotal = 0;
  cashGrandTotal = 0;
  coinDataB: any[] = [];
  cashListB: any[] = [];
  productsB: any[] = [];
  coinGrandTotalB = 0;
  cashGrandTotalB = 0;
  entry_id: any;
  creditCustomers: any[] = [];
  creditCustomersB: any[] = [];
  closingReading: any;
  cust = { category: 'HSD' };
  date_readonly: any;
  isOpeningReadonly: boolean = false;
  isDateReadonly: boolean = false;
  entry: any;
  userRoles: any;
  selectedDate: string = '';
  approval_list: any;
  hasTotalLimitError = false;
  constructor(private serverService: Server, private http: HttpClient, private router: Router) {

  }

  pumpSelection: { [key: string]: boolean } = {
    // 'pump1-nozzle1-petrol': false,
    // 'pump1-nozzle2-diesel': false,
    // 'pump2-nozzle1-petrol': false,
    // 'pump2-nozzle2-diesel': false
  };
  isLoading: boolean = false;
  rpsPrice: any[] = [];
  operators: any[] = [];
  keyword: string = '';
  isPumpSelectedA: boolean = false;
  isPumpSelectedB: boolean = false;
  errorMessages: string[] = [];
  selectedPump1: string | null = null;
  selectedPump2: string | null = null;
  selectedPump: string | null = null;
  postShiftA: boolean = false;
  postShiftB: boolean = false;
  isSaveButtonVisible = true;
  saveMessage = '';
  value: string = '0.00';
  isOpeningFocusedIndex: number | null = null;
  isClosingFocusedIndex: number | null = null;
  isTestFuelFocusedIndex: number | null = null;
  isShiftreceiptFocusedIndex: number | null = null;
  isShiftgpayFocusedIndex: number | null = null;
  isShiftphonepeFocusedIndex: number | null = null;
  isShiftswipingFocusedIndex: number | null = null;
  isShiftdiscountFocusedIndex: number | null = null;
  isShiftextrafuelFocusedIndex: number | null = null;
  isshiftmanualdifferenceFocusedIndex: number | null = null;
  showPopup = false;
  approvalDate: string | undefined;
  approvalAmount: number | undefined;

  shiftA = {
    entries: [{
      shiftDate: '',
      pump: '',
      shift: '',
      nozzle: '',
      fuelType: '',
      opening: 0,
      openingDisplay: '0.00',
      closing: 0,
      closingDisplay: '0.00',
      sales: 0,
      operatorId: 0,
      operatorName: '',
      price: 0,
      total: 0,
      testfuel: 0,
      testfuelDisplay: '0.00',
      testfuelamoutnt: 0,
      shiftcoins: 0,
      shiftgpay: 0,
      shiftgpayDisplay: '0.00',
      shiftphonepeDisplay: '0.00',
      shiftphonepe: 0,
      shiftswiping: 0,
      shiftswipingDisplay: '0.00',
      shiftcash: 0,
      shiftcredit: 0,
      shifttotal: 0,
      shiftreceipt: 0,
      shiftreceiptDisplay: '0.00',
      shiftgrandtotal: 0,
      shiftfueltotal: 0,
      shiftoilsales: 0,
      shiftdiscount: 0,
      shiftdiscountDisplay: '0.00',
      shiftextrafuelDisplay: '0.00',
      shiftextrafuel: 0,
      shiftgtotal: 0,
      shiftdifference: 0,
      shiftmanualdifference: 0,
      shiftmanualdifferenceDisplay: '0.00',
      shifevtotal: 0,
      ev_entry: [
        { ev_hours: 0, rate: 0, total: 0 }
      ],
      errors: {} as Record<string, string>
    }],
  };

  shiftB = {
    entries: [{
      shiftDate: '',
      pump: '',
      shift: '',
      nozzle: '',
      fuelType: '',
      opening: 0,
      openingDisplay: '0.00',
      closing: 0,
      closingDisplay: '0.00',
      sales: 0,
      operatorId: 0,
      operatorName: '',
      price: 0,
      total: 0,
      testfuel: 0,
      testfuelDisplay: '0.00',
      testfuelamoutnt: 0,
      shiftcoins: 0,
      shiftgpay: 0,
      shiftgpayDisplay: '0.00',
      shiftphonepe: 0,
      shiftphonepeDisplay: '0.00',
      shiftswiping: 0,
      shiftswipingDisplay: '0.00',
      shiftcash: 0,
      shiftcredit: 0,
      shifttotal: 0,
      shiftreceipt: 0,
      shiftreceiptDisplay: '0.00',
      shiftgrandtotal: 0,
      shiftfueltotal: 0,
      shiftoilsales: 0,
      shiftdiscount: 0,
      shiftextrafuel: 0,
      shiftdiscountDisplay: '0.00',
      shiftextrafuelDisplay: '0.00',
      shiftgtotal: 0,
      shiftdifference: 0,
      shiftmanualdifference: 0,
      shiftmanualdifferenceDisplay: '0.00',
      shifevtotal: 0,
      ev_entry: [
        { ev_hours: 0, rate: 0, total: 0 }
      ],
      errors: {} as Record<string, string>
    }],
  };

  ngOnInit() {
    this.userRoles = JSON.parse(localStorage.getItem('roles') || '[]');
    const today = new Date();
    const ddMMyyyy = today.toISOString().split('T')[0];
    this.shiftA.entries[0].shiftDate = ddMMyyyy;
    this.shiftB.entries[0].shiftDate = ddMMyyyy;
    this.getOperator();
    this.getRpsprice(ddMMyyyy);
    this.getCaseCoinType();
    this.getCustomer();
  }
  home() {
    this.router.navigate(['/dashboard']);
  }
  toggleCoinCollapse() {
    this.coinCollapseVisible = !this.coinCollapseVisible;
  }
  toggleCashCollapse() {
    this.cashCollapseVisible = !this.cashCollapseVisible;
  }
  toggleEvtotalCollapse() {
    this.evtotalCollapseVisible = !this.evtotalCollapseVisible;
  }
  toggleCoinCollapseB() {
    this.coinCollapseVisibleB = !this.coinCollapseVisibleB;
  }
  toggleEvtotalCollapseB() {
    this.evtotalCollapseVisibleB = !this.evtotalCollapseVisibleB;
  }
  toggleCashCollapseB() {
    this.cashCollapseVisibleB = !this.cashCollapseVisibleB;
  }
  toggleOilCollapse() {
    this.oilCollapseVisible = !this.oilCollapseVisible;
  }
  toggleOilCollapsB() {
    this.oilCollapseVisibleB = !this.oilCollapseVisibleB;
  }
  toggleCreditCollapse() {
    this.creditCollapseVisible = !this.creditCollapseVisible;
  }
  toggleCreditCollapseB() {
    this.creditCollapseVisibleB = !this.creditCollapseVisibleB;
  }
  getCaseCoinType() {
    const requestData = { api_url: 'get_cashCoinTypes' };
    this.serverService.sendServerGet(requestData).subscribe({
      next: (response: any) => {
        if (response.status == 'true' || response.status == true) {
          this.coinData = response.coins_type.map((coin: { coins: any; }) => ({
            coins: coin.coins,
            count: 0,
          }));
          this.coinDataB = response.coins_type.map((coin: { coins: any; }) => ({
            coins: coin.coins,
            count: 0,
          }));

          this.cashList = response.cash_type.map((cash: { cash: any; }) => ({
            cash: cash.cash,
            count: 0,
          }));
          this.cashListB = response.cash_type.map((cash: { cash: any; }) => ({
            cash: cash.cash,
            count: 0,
          }));
          this.products = response.products.map((p: any) => ({
            product_id: p.id,
            product_name: p.name,
            quantity: 0,
            price: parseFloat(p.price),
            total_ml: 0,
            liters: 0
          }));
          console.log('this.products', this.products);

          this.productsB = response.products.map((p: any) => ({
            product_id: p.id,
            product_name: p.name,
            quantity: 0,
            price: parseFloat(p.price),
            total_ml: 0,
            liters: 0
          }));

        }
      },
      error: (err) => console.error('❌ Network/API error', err)
    });
  }

  getOperator(keyword: string = ''): void {
    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'get_operators',
      user_id: user_id,
      keyword: keyword,
    };
    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        console.log('Login Response:', response);

        // Check if the response contains the operator list and assign it to operators
        if (response && response.operator_list) {
          this.operators = response.operator_list.map((op: any) => ({
            id: op.user_id,
            name: op.full_name
          }));
        }
      },
      error: (err) => {
        console.error('Error fetching operators:', err);
      }
    });
  }
  onOperatorChange(selected: any, index: number) {
    if (selected) {
      if (this.shiftA?.entries?.[index]) {
        this.shiftA.entries[index].operatorId = selected.id;
        this.shiftA.entries[index].operatorName = selected.name;
      }
      if (this.shiftB?.entries?.[index]) {
        this.shiftB.entries[index].operatorId = selected.id;
        this.shiftB.entries[index].operatorName = selected.name;
      }
      console.log('Operator selected:', selected.id, selected.name);
    } else {
      if (this.shiftA?.entries?.[index]) {
        this.shiftA.entries[index].operatorId = 0;
        this.shiftA.entries[index].operatorName = '';
      }
      if (this.shiftB?.entries?.[index]) {
        this.shiftB.entries[index].operatorId = 0;
        this.shiftB.entries[index].operatorName = '';
      }
      console.log('Operator cleared');
    }
  }

  getCustomer(keyword: string = ''): void {
    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'get_customer',
      user_id: user_id,
      keyword: keyword,
    };
    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        console.log('Login Response:', response);

        // Check if the response contains the operator list and assign it to operators
        if (response && response.customer_list) {
          this.customerOptions = response.customer_list.map((cust: any) => ({
            id: cust.cusId,
            name: cust.customername,
            category: 'HSD',
            liters: 0,
            credit_limit: Number(cust.credit_limit),
            customertotal: 0
          }));
          this.customerOptionsB = response.customer_list.map((cust: any) => ({
            id: cust.cusId,
            name: cust.customername,
            category: 'HSD',
            liters: 0,
            customertotal: 0
          }));
        }
      },
      error: (err) => {
        console.error('Error fetching operators:', err);
      }
    });
  }
  // onCustomersChange(selected: any, index: number): void {
  //   console.log('Selected customer:', selected);
  //   this.creditCustomers[index].customer_id = selected?.id || null;
  // }
  onCustomersChange(selectedCustomer: any, index: number) {
    // Ensure the object exists
    if (!selectedCustomer) {
      // Clear the customer at the given index
      this.creditCustomers[index] = {
        customer_id: null,
        customer_name: null,
        selectedCustomer: null,
        category: 'HSD',
        liters: 0,
        vehicle: '',
        customertotal: 0,
        maxLimit: 0,
        exceedsLimit: false,
        within_terms: true,
        allowed_credit: true
      };
      return; // Early exit if no customer is selected
    }
    if (!this.creditCustomers[index]) {
      this.creditCustomers[index] = {
        customer_id: null,
        customer_name: null,
        selectedCustomer: null,
        category: 'HSD',
        liters: 0,
        vehicle: '',
        customertotal: 0,
        maxLimit: 0,
        exceedsLimit: false,
        within_terms: true,
        allowed_credit: true
      };
    }

    const cust = this.creditCustomers[index];

    cust.exceedsLimit = false;
    cust.within_terms = true;
    cust.allowed_credit = true;
    cust.maxLimit = 0;
    cust.customertotal = 0;

    cust.customer_id = selectedCustomer?.id ?? null;
    cust.customer_name = selectedCustomer?.name ?? null;
    cust.selectedCustomer = selectedCustomer ?? null;
    // cust.maxLimit = Number(selectedCustomer.credit_limit);
    console.log('Updated customer:', cust);
    this.getEligibleCustomers(cust.customer_id);
    //this.updateCustomerTotal(index);
  }
  getEligibleCustomers(customerId: number | null) {
    const user_id = localStorage.getItem('user_id');
    if (!customerId) {
      console.log("No valid customer ID found.");
      return;
    }

    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "getEligibleCustomers",
      user_id: user_id,
      customer_id: customerId.toString()
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        console.log('API Response:', response);
        if (response.data) {
          const data = response.data;
          const cust = this.creditCustomers.find(c => c.customer_id === data.id);

          if (cust) {
            cust.customer_name = data.name;
            cust.maxLimit = Number(data.credit_limit);
            cust.within_terms = data.within_terms;
            cust.allowed_credit = data.allowed_credit;

            cust.exceedsLimit = !data.within_terms || !data.allowed_credit;
            this.updateCustomerTotal(this.creditCustomers.indexOf(cust));
          }
        }
      },
      error: (err) => {
        console.error('Error fetching customer data:', err);
      }
    });
  }
  onCustomersChangeB(selectedCustomer: any, index: number) {
    if (!selectedCustomer) {
      this.creditCustomersB[index] = {
        customer_id: null,
        customer_name: '',
        selectedCustomer: null,
        category: 'HSD',
        liters: 0,
        vehicle: '',
        customertotal: 0,
        maxLimit: 0,
        exceedsLimit: false,
        within_terms: true,
        allowed_credit: true
      };
      return;
    }

    const cust = this.creditCustomersB[index];

    cust.exceedsLimit = false;
    cust.within_terms = true;
    cust.allowed_credit = true;
    cust.maxLimit = 0;
    cust.customertotal = 0;

    cust.customer_id = selectedCustomer.id;
    cust.customer_name = selectedCustomer.name;
    cust.selectedCustomer = selectedCustomer;

    // Fetch customer data (just like Shift A)
    this.getEligibleCustomersB(cust.customer_id, index);
  }
  getEligibleCustomersB(customerId: number | null, index: number) {
    if (!customerId) return;

    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "getEligibleCustomers",
      user_id: user_id,
      customer_id: customerId.toString()
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        if (response.data) {
          const data = response.data;
          const cust = this.creditCustomersB[index];

          cust.customer_name = data.name;
          cust.maxLimit = Number(data.credit_limit);
          cust.within_terms = data.within_terms;
          cust.allowed_credit = data.allowed_credit;
          cust.exceedsLimit = !data.within_terms || !data.allowed_credit;

          this.updateCustomerTotalB(index);
        }
      },
      error: (err) => {
        console.error('Error fetching customer data for Shift B:', err);
      }
    });
  }





  // removeCustomer(index: number) {
  //   this.creditCustomers[index] = {
  //     customer_id: null,
  //     customer_name: null,
  //     selectedCustomer: null,
  //     category: 'HSD',
  //     liters: 0,
  //     vehicle: '',
  //     customertotal: 0,
  //     maxLimit: 0,
  //     exceedsLimit: false
  //   };
  //   console.log('Customer removed at index', index);
  // }


  onCustSearchChange(event: any): void {
    this.keyword = event.term;
    this.getCustomer(this.keyword);
  }
  getRpsprice(selectedDate: string, callback?: () => void): void {
    // this.getCaseCoinType();
    //this.isLoading = true;
    const accessToken = localStorage.getItem('access_token');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`,
      'Accept': 'application/json'
    });

    const formattedDate = encodeURIComponent(selectedDate);
    const url = `https://petrosoul.com/api/get_price?date=${formattedDate}`; 
    //const url = `https://petrosoul.com/demo/api/get_price?date=${formattedDate}`;

    this.http.get<any>(url, { headers }).subscribe({
      next: (res) => {
        // this.rpsPrice = res.data;
        // this.rpsPriceMessage = res.message;
        // console.log('Price list:', this.rpsPrice);
        // if (callback) callback();

        if (res && Array.isArray(res.data) && res.data.length > 0) {
          this.rpsPrice = res.data;
          this.rpsPriceMessage = res.message || 'Price data loaded successfully';
          console.log('Price list:', this.rpsPrice);
        } else {
          this.rpsPrice = [];
          this.rpsPriceMessage = 'No price data available';
          console.warn('Received invalid or empty price data:', res);
        }
        if (Array.isArray(this.rpsPrice) && this.rpsPrice.length > 0 && callback) {
          callback();
        }
        this.isLoading = false;
      },
      error: (err) => {
        this.rpsPrice = [];
        console.error('Failed to load roles:', err);
        this.isLoading = false;
      }
    });
  }
  onSearchChange(event: any): void {
    this.keyword = event.term;
    this.getOperator(this.keyword);
  }

  private n(v: any): number { return typeof v === 'number' ? v : parseFloat(v) || 0; }

  private updateSales(entry: any) {
    const opening = this.n(entry.opening);
    const closing = this.n(entry.closing);
    const price = this.n(entry.price);
    const testfuel = this.n(entry.testfuel);

    entry.sales = Math.max(0, closing - opening);

    const salesAmount = +(entry.sales * price).toFixed(2);
    const testFuelAmount = +(testfuel * price).toFixed(2);
    const total = +(salesAmount - testFuelAmount).toFixed(2);


    entry.testfuelamoutnt = testFuelAmount;
    entry.total = total;
  }
  private calculateTotals(entries: any[]) {
    // this.clearError(0, 'total');
    // this.clearError(0, 'price');
    entries.forEach(e => {
      const salesAmount = +((this.n(e.sales) * this.n(e.price))).toFixed(2);
      const testFuelAmount = +(this.n(e.testfuel) * this.n(e.price)).toFixed(2);
      e.testfuelamoutnt = testFuelAmount;
      e.total = +(salesAmount - testFuelAmount).toFixed(2);
      e.testFuelDiff = +(testFuelAmount - e.total).toFixed(2);
    });

    const e0 = entries[0];

    // 1. Fuel Total
    e0.shiftfueltotal = +(
      entries.reduce((sum, e) => sum + this.n(e.total), 0)
    ).toFixed(2);

    // 2. Gross Total Calculation
    e0.shiftgtotal = +(
      this.n(e0.shiftfueltotal)
      - this.n(e0.shifttest)
      + this.n(e0.shiftoilsales)
      + this.n(e0.shifevtotal)
      - this.n(e0.shiftdiscount)
      - this.n(e0.shiftextrafuel)
    ).toFixed(2);

    // 3. Total Payment Modes
    e0.shifttotal = +(
      this.n(e0.shiftcoins) +
      this.n(e0.shiftgpay) +
      this.n(e0.shiftphonepe) +
      this.n(e0.shiftswiping) +
      this.n(e0.shiftcash) +
      this.n(e0.shiftcredit)
    ).toFixed(2);

    // 4. Grand Total
    e0.shiftgrandtotal = +(
      this.n(e0.shifttotal) - this.n(e0.shiftreceipt)
    ).toFixed(2);

    // 5. Difference
    e0.shiftdifference = +(
      this.n(e0.shiftgrandtotal) - this.n(e0.shiftgtotal)
    ).toFixed(2);
  }
  updateSalesA(index: number) {
    this.updateSales(this.shiftA.entries[index]);
    this.calculateTotals(this.shiftA.entries);
  }

  updateSalesB(index: number) {
    this.updateSales(this.shiftB.entries[index]);
    this.calculateTotals(this.shiftB.entries);
  }

  calculateTotalsA() {
    this.calculateTotals(this.shiftA.entries);
  }


  calculateTotalsB() {
    this.calculateTotals(this.shiftB.entries);
  }
  calculateEvTotalA() {
    const entry = this.shiftA.entries[0].ev_entry[0];
    entry.total = (entry.ev_hours || 0) * (entry.rate || 0);
    this.shiftA.entries[0].shifevtotal = entry.total;
    this.calculateTotalsA();
  }
  calculateEvTotalB() {
    const entry = this.shiftB.entries[0].ev_entry[0];
    entry.total = (entry.ev_hours || 0) * (entry.rate || 0);
    this.shiftB.entries[0].shifevtotal = entry.total;
    this.calculateTotalsB();
  }

  private mapCoins(coinData: any[]) {
    return coinData.map(c => ({
      denomination: c.coins,
      quantity: c.count || 0,
      total: (c.coins || 0) * (c.count || 0)
    }));
  }

  private mapCash(cashList: any[]) {
    return cashList.map(c => ({
      denomination: c.cash,
      quantity: c.count || 0,
      total: (c.cash || 0) * (c.count || 0)
    }));
  }

  private mapProducts(products: any[]) {
    return products
      .filter(p => p.quantity > 0)
      .map(p => ({
        product_name: p.product_name,
        product_id: p.product_id,
        quantity: p.quantity,
        price: p.price,
        total_ml: p.total_ml,
        liters: p.liters?.toString() || "0"
      }));
  }
  private mapCreditCustomers(customers: any[]) {
    return customers.map(cust => ({
      customer_id: cust.selectedCustomer?.id ?? cust.customer_id ?? null,
      customer_name: cust.selectedCustomer?.name ?? cust.customer_name ?? null,
      fuel_type: cust.category,
      liters: cust.liters,
      vehicle_number: cust.vehicle,
      slip_no: cust.slip_no,
      rate: cust.rate || cust.price || null,
      total: cust.customertotal
    }));
  }

  private mapEv(evEntry: any[]) {
    return evEntry?.map((ev: any) => ({
      ev_hours: ev.ev_hours || 0,
      rate: ev.rate || 0,
      total: ev.total || 0
    })) || [];
  }





  validateShift(shift: any): boolean {
    const entry = shift.entries[0];
    const entry1 = shift.entries[1];
    entry.errors = {}; // reset

    let isValid = true;

    if (!entry.operatorId) {
      entry.errors['operatorId'] = 'Operator is required';
      isValid = false;
    }

    // if (entry.sales == null || isNaN(entry.sales) || entry.sales == 0) {
    //   entry.errors['sales'] = 'Sales is required';
    //   isValid = false;
    // }
    // if (entry1.sales == null || isNaN(entry1.sales) || entry1.sales == 0) {
    //   entry1.errors['sales'] = 'Sales is required';
    //   isValid = false;
    // }

    if (entry1.opening == null || isNaN(entry1.opening) || entry1.opening == 0) {
      entry1.errors['opening'] = 'Opening is required';
      isValid = false;
    }
    if (entry.opening == null || isNaN(entry.opening) || entry.opening == 0) {
      entry.errors['opening'] = 'Opening is required';
      isValid = false;
    }

    if (entry.closing == null || isNaN(entry.closing) || entry.closing == 0) {
      entry.errors['closing'] = 'Closing is required';
      isValid = false;
    }
    if (entry1.closing == null || isNaN(entry1.closing) || entry1.closing == 0) {
      entry1.errors['closing'] = 'Closing is required';
      isValid = false;
    }

    return isValid;
  }
  resetLimitFlags() {
    // Reset the limit checks
    this.resetHasExceededLimit('A');
    this.resetHasExceededLimit('B');
  }

  resetHasExceededLimit(shift: 'A' | 'B') {
    if (shift === 'A') {
      this.creditCustomers.forEach(c => {
        c.exceedsLimit = false;
        c.selectedCustomer = '';
      });
    } else {
      this.creditCustomersB.forEach(c => {
        c.exceedsLimit = false;
        c.selectedCustomer = '';
      });
    }
  }
  get hasAnyExceededLimit(): boolean {
    return this.creditCustomers.some(c =>
      c.selectedCustomer && (!c.within_terms || !c.allowed_credit)
    );
  }
  get hasAnyExceededLimitB(): boolean {
    return this.creditCustomersB.some(c =>
      c.selectedCustomer && (!c.within_terms || !c.allowed_credit)
    );
  }

  // 🔹 Save Function (common for A & B)
  saveShift(shift: any, label: 'A' | 'B') {
    this.isLoading = true;
    const isValid = this.validateShift(shift);

    if (!isValid) {
      console.warn(`Shift ${label} form is invalid.`);
      this.isLoading = false;
      return;
    }
    if (this.hasAnyExceededLimit) {
      iziToast.error({
        message: 'Some customers exceeded their credit limit or are not allowed credit.',
        position: 'topRight'
      });
      this.isLoading = false;
      return;
    }
    if (this.hasAnyExceededLimitB) {
      iziToast.error({
        message: 'Some customers exceeded their credit limit or are not allowed credit.',
        position: 'topRight'
      });
      this.isLoading = false;
      return;
    }
    // if (this.isValidShift(shift)) {s
    const entry = shift.entries[0];
    //       if (!this.validateEntry(entry)) {
    //   this.isLoading = false; 
    //   return;
    // }
    const requestData = {
      ...this.buildShiftRequest(entry, label),
      api_url: "shiftEntrySave"
    };
    console.log('requestData', requestData);
    // return false;
    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        this.isLoading = false;
        if (response.status) {
          iziToast.success({
            message: `Shift ${label} saved successfully!`,
            position: 'topRight'
          });
          this.entry_id = response.entry_id || response.data?.id || response.shift_entry?.id;
          this.date_readonly = response.date_readonly || response.data?.date_readonly;

          // ✅ After save, show Post button
          if (label === 'A') this.postShiftA = true;
          if (label === 'B') this.postShiftB = true;
          this.isDateReadonly = response.hint == 'date_readonly';
          console.log('this.isDateReadonly', this.isDateReadonly)
        } else {
          iziToast.error({ message: response.message, position: 'topRight' });
        }
      },
      error: (err) => {
        this.isLoading = false;
        iziToast.error({ message: `Error saving Shift ${label}`, position: 'topRight' });
        console.error(err);
      }
    });
    // } else {
    // this.isLoading = false;
    // iziToast.error({
    //   message: `Validation error while saving Shift ${label}`,
    //   position: 'topRight',
    // });
    //}

  }

  // 🔹 Post Function (common for A & B)
  postShift(shift: any, label: 'A' | 'B') {
    const entry = shift.entries[0];
    // ✅ Block if difference is not zero
    // if (Number(entry.shiftdifference) !== 10) {
    //   iziToast.error({
    //     message: `Shift ${label} cannot be posted. Difference must be 0.`,
    //     position: 'topRight'
    //   });
    //   return; 
    // }

    this.isLoading = true;

    if (this.hasAnyExceededLimit) {
      iziToast.error({
        message: 'Some customers exceeded their credit limit or are not allowed credit.',
        position: 'topRight'
      });
      this.isLoading = false;
      return;
    }
    if (this.hasAnyExceededLimitB) {
      iziToast.error({
        message: 'Some customers exceeded their credit limit or are not allowed credit.',
        position: 'topRight'
      });
      this.isLoading = false;
      return;
    }
    const requestData = {
      ...this.buildShiftRequest(entry, label),
      api_url: "shiftEntryPost",
      id: this.entry_id
    };
    console.log('requestData', requestData);

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        this.isLoading = false;
        if (response.status) {
          iziToast.success({
            message: `Shift ${label} posted successfully!`,
            position: 'topRight'
          });
          this.selectedPump = null;
          if (label === 'A') {
            this.onCancelA();
          }
          if (label === 'B') {
            this.onCancelB();
          }
        } else {
          iziToast.error({ message: response.message, position: 'topRight' });
        }
      },
      error: (err) => {
        this.isLoading = false;
        iziToast.error({ message: `Error posting Shift ${label}`, position: 'topRight' });
        console.error(err);
      }
    });
  }

  // 🔹 Common builder for Save & Post
  buildShiftRequest(entry: any, label: 'A' | 'B') {
    const user_id = localStorage.getItem('user_id');
    const shift = label === 'A' ? this.shiftA : this.shiftB;

    // Default values
    const request: any = {
      moduleType: "shift_entry",
      api_type: "api",
      user_id: user_id,
      shift_entry: {
        shift_date: entry.shiftDate,
        shift: entry.shift,
        pump_no: entry.pump,
        operator_id: entry.operatorId || "",
        operator_name: entry.operatorName,
        shift_fuel_total: entry.shiftfueltotal,
        test_fuel: entry.shifttest,
        oil_sale: entry.shiftoilsales,
        discount: entry.shiftdiscount,
        extra_fuel: entry.shiftextrafuel,
        coins: entry.shiftcoins,
        gpay: entry.shiftgpay,
        phonepe: entry.shiftphonepe,
        swipping: entry.shiftswiping,
        cash: entry.shiftcash,
        credit: entry.shiftcredit,
        payment_total: entry.shifttotal,
        receipt: entry.shiftreceipt,
        grand_total_1: entry.shiftgrandtotal,
        grand_total_2: entry.shiftgtotal,
        difference: entry.shiftdifference,
        manual_difference: entry.shiftmanualdifference,
        ev_total: entry.shifevtotal,
        coins_denom: label === 'A' ? this.mapCoins(this.coinData) : this.mapCoins(this.coinDataB),
        cash_denom: label === 'A' ? this.mapCash(this.cashList) : this.mapCash(this.cashListB),
        product_entry: label === 'A' ? this.mapProducts(this.products) : this.mapProducts(this.productsB),
        customer_credit: label === 'A' ? this.mapCreditCustomers(this.creditCustomers) : this.mapCreditCustomers(this.creditCustomersB),
        ev_entry: this.mapEv(entry.ev_entry)
      },
    };

    // ✅ Loop through MS, HSD, etc.
    shift.entries.forEach((fuelEntry: any) => {
      if (fuelEntry.fuelType === "Petrol" || fuelEntry.fuelType === "MS") {
        request.shift_entry.ms_fuel_type = "Petrol";
        request.shift_entry.ms_opening_reading = fuelEntry.opening;
        request.shift_entry.ms_closing_reading = fuelEntry.closing;
        request.shift_entry.ms_total_sales = fuelEntry.sales;
        request.shift_entry.ms_price = fuelEntry.price;
        request.shift_entry.ms_test_liters = fuelEntry.testfuel || 0;
        request.shift_entry.ms_test_amount = fuelEntry.testfuelamoutnt || 0;
        request.shift_entry.ms_total_amount = fuelEntry.total;
      }

      if (fuelEntry.fuelType === "Diesel" || fuelEntry.fuelType === "HSD") {
        request.shift_entry.hsd_fuel_type = "Diesel";
        request.shift_entry.hsd_opening_reading = fuelEntry.opening;
        request.shift_entry.hsd_closing_reading = fuelEntry.closing;
        request.shift_entry.hsd_total_sales = fuelEntry.sales;
        request.shift_entry.hsd_price = fuelEntry.price;
        request.shift_entry.hsd_test_liters = fuelEntry.testfuel || 0;
        request.shift_entry.hsd_test_amount = fuelEntry.testfuelamoutnt || 0;
        request.shift_entry.hsd_total_amount = fuelEntry.total;
      }
    });

    return request;
  }



  calculateCashTotal(key: string) {
    this.cashData[key].grandTotal = this.cashData[key].cashType.reduce((total: number, cash: { denomination: number; count: number; }) => {
      return total + (cash.denomination * cash.count);
    }, 0);
  }


  updateCashTotal() {
    // this.cashGrandTotal = this.cashList.reduce(
    //   (sum, item) => sum + item.cash * (item.count || 0), 0
    // );
    this.cashList.forEach(item => {
      item.count = Math.floor(parseFloat(item.count) || 0);
    });

    this.cashGrandTotal = this.cashList.reduce(
      (sum, item) => sum + (item.cash * item.count),
      0
    );

    this.shiftA.entries[0].shiftcash = this.cashGrandTotal;
    this.calculateTotalsA();
  }
  updateCoinTotal() {
    this.coinGrandTotal = 0;
    this.coinData.forEach(item => {
      item.count = Math.floor(parseFloat(item.count) || 0);
    });

    this.coinGrandTotal = this.coinData.reduce(
      (sum, item) => sum + (item.coins * item.count),
      0
    );
    this.shiftA.entries[0].shiftcoins = this.coinGrandTotal;
    this.calculateTotalsA();
  }
  updateCashTotalB() {
    this.cashListB.forEach(item => {
      item.count = Math.floor(Number(item.count) || 0);
    });

    this.cashGrandTotalB = this.cashListB.reduce(
      (sum, item) => sum + (item.cash * item.count),
      0
    );

    this.shiftB.entries[0].shiftcash = this.cashGrandTotalB;
    this.calculateTotalsB();
  }
  preventDecimal(event: KeyboardEvent) {
    if (event.key === '.' || event.key === ',') {
      event.preventDefault();
    }
  }
  updateCoinTotalB() {
    this.coinGrandTotalB = 0;
    // this.coinGrandTotalB = this.coinDataB.reduce(
    //   (sum, item) => sum + item.coins * (item.count || 0), 0
    // );
    this.coinDataB.forEach(item => {
      item.count = Math.floor(Number(item.count) || 0);
    });

    this.coinGrandTotalB = this.coinDataB.reduce(
      (sum, item) => sum + (item.coins * item.count),
      0
    );
    this.shiftB.entries[0].shiftcoins = this.coinGrandTotalB;
    this.calculateTotalsB();
  }

  // addProduct() {
  //   this.products.push({ product_name: "", quantity: 0, total_ml: 0, liters: "0.00" });
  // }
  // addProductB() {
  //   this.productsB.push({ product_name: "", quantity: 0, total_ml: 0, liters: "0.00" });
  // }

  // removeProduct(index: number) {
  //   this.products.splice(index, 1);
  //   if (this.products.length > 0) {
  //     this.products.forEach(p => this.updateProductTotals(p));
  //   } else {
  //     this.shiftA.entries[0].shiftoilsales = 0;
  //   }
  //   this.calculateTotalsA();
  // }


  // removeProductB(index: number) {
  //   this.productsB.splice(index, 1);
  //   if (this.productsB.length > 0) {
  //     this.productsB.forEach(p => this.updateProductTotalsB(p));
  //   } else {
  //     this.shiftB.entries[0].shiftoilsales = 0;
  //   }
  //   this.calculateTotalsB();
  // }

  updateProductTotals(p: any) {
    p.quantity = Number(p.quantity || 0);
    p.price = Number(p.price || 0)
    p.total_ml = p.quantity * p.price;
    p.liters = p.total_ml / 1000;
    this.shiftA.entries[0].shiftoilsales = this.products.reduce((sum, pr) => {
      return sum + (pr.total_ml || 0);
    }, 0);
    this.calculateTotalsA();
  }
  updateProductTotalsB(p: any) {
    p.quantity = Number(p.quantity || 0);
    p.price = Number(p.price || 0)
    p.total_ml = p.quantity * p.price;
    p.liters = p.total_ml / 1000;
    this.shiftB.entries[0].shiftoilsales = this.productsB.reduce((sum, pr) => {
      return sum + (pr.total_ml || 0);
    }, 0);
    this.calculateTotalsB();
  }
  checkValidationStatusB(): void {
    const hasInvalid = this.creditCustomersB.some(
      c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
    );

    this.validateFieldsB = hasInvalid;
  }
  checkValidationStatusA(): void {
    const hasInvalid = this.creditCustomers.some(
      c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
    );

    this.validateFieldsA = hasInvalid;
  }
  // addCustomer(): void {

  //   this.creditCustomers.push({
  //     customer_id: null,
  //     category: 'HSD',
  //     liters: 0,
  //     vehicle: '',
  //     slip_no:'',
  //     customertotal: 0,
  //     maxLimit: undefined,
  //     exceedsLimit: false
  //   });
  // }
  addCustomer(): void {
    if (this.creditCustomers.length === 0 || this.creditCustomers.length > 0) {
      this.creditCustomers.push({
        vehicle: '',
        slip_no: '',
        category: 'HSD',
        customer_id: null,
        liters: 0,
        customertotal: 0,
        maxLimit: undefined,
        exceedsLimit: false
      });

      this.validateFieldsA = true;
      return;
    }

    const hasInvalid = this.creditCustomers.some(
      c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
    );

    if (hasInvalid) {
      this.validateFieldsA = true;
      return;
    }

    this.validateFieldsA = false;

    this.creditCustomers.push({
      vehicle: '',
      slip_no: '',
      category: 'HSD',
      customer_id: null,
      liters: 0,
      customertotal: 0,
      maxLimit: undefined,
      exceedsLimit: false
    });
  }

  addCustomerB(): void {
    // If there are no rows, just add the first row and show validation
    if (this.creditCustomersB.length > 0 || this.creditCustomersB.length === 0) {
      this.creditCustomersB.push({
        vehicle: '',
        slip_no: '',
        category: 'HSD',
        customer_id: null,
        liters: 0,
        customertotal: 0,
        maxLimit: undefined,
        exceedsLimit: false
      });

      this.validateFieldsB = true; // show validation right away
      return;
    }

    // For existing rows, validate before allowing new row
    const hasInvalid = this.creditCustomersB.some(
      c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
    );

    if (hasInvalid) {
      this.validateFieldsB = true;
      return; // block add until fixed
    }

    // All good: add another row
    this.validateFieldsB = false;

    this.creditCustomersB.push({
      vehicle: '',
      slip_no: '',
      category: 'HSD',
      customer_id: null,
      liters: 0,
      customertotal: 0,
      maxLimit: undefined,
      exceedsLimit: false
    });
  }


  // removeCust(index: number): void {
  //   this.creditCustomers.splice(index, 1);
  //   if (this.creditCustomers.length > 0) {
  //     this.updateCustomerTotal(0);
  //   } else {
  //     this.shiftA.entries[0].shiftcredit = 0;
  //   }
  //   this.calculateTotalsA();
  // }
  removeCust(index: number): void {
    this.creditCustomers.splice(index, 1);
    const hasInvalid = this.creditCustomers.some(
      c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
    );

    this.validateFieldsA = hasInvalid;
    if (this.creditCustomers.length === 0) {
      this.validateFieldsA = false;
    }
  }
  removeCustB(index: number): void {
    this.creditCustomersB.splice(index, 1);
    const hasInvalid = this.creditCustomersB.some(
      c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
    );

    this.validateFieldsB = hasInvalid;
    if (this.creditCustomersB.length === 0) {
      this.validateFieldsB = false;
    }
  }


  updateCustomerTotal(index: number): void {
    const cust = this.creditCustomers[index];
    if (!cust.shiftDate) {
      cust.shiftDate = new Date().toISOString().split('T')[0];
    }
    const fuelCategory = cust.category || 'HSD';
    this.setFuelPrice(cust, fuelCategory);
    const total = (Number(cust.liters) || 0) * (Number(cust.price) || 0);
    console.log(cust.price);
    cust.customertotal = parseFloat(total.toFixed(2));

    const grand_total = this.creditCustomers.reduce((sum, c) => sum + (Number(c.customertotal) || 0), 0);
    this.shiftA.entries[0].shiftcredit = grand_total;
    this.calculateTotalsA();
  }
  updateCustomerTotalB(index: number): void {
    const cust = this.creditCustomersB[index];
    if (!cust.shiftDate) {
      cust.shiftDate = new Date().toISOString().split('T')[0];
    }
    const fuelCategory = cust.category || 'HSD';
    this.setFuelPrice(cust, fuelCategory);
    // const liters = +cust.liters || 0;
    // const price = +cust.price || 0;
    const total = (Number(cust.liters) || 0) * (Number(cust.price) || 0);
    cust.customertotal = parseFloat(total.toFixed(2));
    const grand_total = this.creditCustomersB.reduce((sum, cust) => {
      return sum + (+cust.customertotal || 0);
    }, 0);
    this.shiftB.entries[0].shiftcredit = grand_total;
    this.calculateTotalsB();

  }



  clearError1(entryIndex: number, fieldName: string) {
    if (this.shiftA.entries[entryIndex]?.errors?.[fieldName]) {
      delete this.shiftA.entries[entryIndex].errors[fieldName];
    }

    // Clear error for shift B
    if (this.shiftB.entries[entryIndex]?.errors?.[fieldName]) {
      delete this.shiftB.entries[entryIndex].errors[fieldName];
    }
  }
  clearError(index: number, field: string): void {
    // Clear from shiftA if exists
    const shiftAentry = this.shiftA?.entries?.[index];
    if (shiftAentry?.errors) {
      delete shiftAentry.errors[field];
    }

    // Clear from shiftB if exists
    const shiftBentry = this.shiftB?.entries?.[index];
    if (shiftBentry?.errors) {
      delete shiftBentry.errors[field];
    }
  }




  validateEntry(entry: any): boolean {
    entry.errors = {};

    if (!entry.opening && entry.opening !== 0) {
      entry.errors['opening'] = 'Opening is required.';
    }
    if (!entry.closing && entry.closing !== 0) {
      entry.errors['closing'] = 'Closing is required.';
    }
    if (entry.opening > entry.closing) {
      entry.errors['opening'] = 'Opening cannot be greater than Closing.';
    }
    if (!entry.total || entry.total <= 0) {
      entry.errors['total'] = 'Total is required.';
    }

    return Object.keys(entry.errors).length === 0;
  }



  nozzleFuelMap: any = {
    MS1: 'Petrol',
    MS2: 'Petrol',
    HSD1: 'Diesel',
    HSD2: 'Diesel'
  };

  getFuelTypeByNozzle(nozzle: string): string {
    return this.nozzleFuelMap[nozzle] || '';
  }

  // Shared method to handle pump selection
  private handlePumpSelection(
    pumpKeys: string[], // <-- now an array
    shift: any,
    shiftFlag: 'A' | 'B',
    selectedDate: string
  ): void {
    // Reset selection
    this.pumpSelection = {};
    pumpKeys.forEach(key => this.pumpSelection[key] = true);

    // Set shift flag
    if (shiftFlag === 'A') {
      this.isPumpSelectedA = true;
    } else {
      this.isPumpSelectedB = true;
    }

    // Clear existing entries
    shift.entries = [];
    this.coinDataB = [];
    // For each pump key (e.g., "pump1-shift1-ms1", "pump1-shift1-hsd1")
    pumpKeys.forEach(pumpKey => {
      const [pump, shiftValue, fuel] = pumpKey.split('-');

      const nozzle = fuel.toUpperCase();
      const fuelCategory = fuel.replace(/[0-9]/g, '').toUpperCase(); // MS, HSD

      const newEntry: any = {
        pump: parseInt(pump.replace('pump', ''), 10),
        shift: shiftValue.replace('shift', 'Shift '),
        nozzle: nozzle,
        fuelType: this.getFuelTypeByNozzle(nozzle),
        operatorId: '',
        closing: 0,
        sales: 0,
        price: 0,
        total: 0,
        // shiftDate: new Date().toISOString().split('T')[0],
        // shiftDate: this.selectedDate,
        shiftDate: selectedDate || new Date().toISOString().split('T')[0],
        errors: {},

        // Optional: Pre-fill all reset fields you had
        shiftcoins: 0,
        shiftgpay: 0,
        shiftphonepe: 0,
        shiftswiping: 0,
        shiftcash: 0,
        shiftcredit: 0,
        shifttotal: 0,
        shiftreceipt: 0,
        shiftgrandtotal: 0,
        shiftfueltotal: 0,
        shifevtotal: 0,
        shifttest: 0,
        shiftoilsales: 0,
        shiftdiscount: 0,
        shiftextrafuel: 0,
        shiftgtotal: 0,
        shiftdifference: 0,
        shiftmanualdifference: 0,
        ev_entry: [{
          ev_hours: '',
          rate: '',
          total: ''
        }]
      };

      // Add the entry
      shift.entries.push(newEntry);

      // Set fuel price
      const isSameDate = this.rpsPrice?.length && this.rpsPrice[0].date === selectedDate;
      if (!isSameDate) {
        this.getRpsprice(selectedDate, () => {
          this.setFuelPrice(newEntry, fuelCategory);
        });
      } else {
        this.setFuelPrice(newEntry, fuelCategory);
      }
    });

    // Reset cash/coin/credit UI for shift A/B
    if (shiftFlag === 'A') {
      this.cashCollapseVisible = false;
      this.coinCollapseVisible = false;
      this.evtotalCollapseVisible = false;
      this.creditCollapseVisible = false;
      this.oilCollapseVisible = false;
      this.cashGrandTotal = 0;
      this.coinGrandTotal = 0;
      this.cashList.forEach(cash => cash.count = 0);
      this.coinData.forEach(coin => coin.count = 0);
    } else {
      this.cashCollapseVisibleB = false;
      this.coinCollapseVisibleB = false;
      this.evtotalCollapseVisibleB = false;
      this.creditCollapseVisibleB = false;
      this.oilCollapseVisibleB = false;
    }
  }

  private setFuelPrice1(entry: any, fuelCategory: string) {
    // const priceEntry = this.rpsPrice.find((item: any) => {
    //   const itemDate = new Date(item.date).toISOString().split('T')[0];
    //   return itemDate === entry.shiftDate;
    // });
    console.log('🛠 shiftDate in entry:', entry.shiftDate);
    console.log('📦 Current rpsPrice array:', this.rpsPrice);

    const priceEntry = this.rpsPrice.find((item: any) => item.date === entry.shiftDate);
    console.log('🔍 Matching priceEntry:', priceEntry);
    if (priceEntry) {
      let price = 0;
      if (fuelCategory === 'MS') {
        price = parseFloat(priceEntry.ms_rate);
      } else if (fuelCategory === 'HSD') {
        price = parseFloat(priceEntry.hsd_rate);
      }

      if (price > 0) {
        entry.price = price;
        console.log(`✅ Price set for ${fuelCategory}:`, entry.price);
      } else {
        console.warn(`⚠️ No rate found for fuel category ${fuelCategory} on ${entry.shiftDate}`);
      }
    } else {
      console.warn(`⚠️ No price data found for date ${entry.shiftDate}`);
    }
  }

  private setFuelPrice(entry: any, fuelCategory: string) {
    if (!entry.shiftDate) return;

    const normalize = (dateStr: string) =>
      new Date(dateStr).toISOString().split('T')[0]; // YYYY-MM-DD

    const entryDate = normalize(entry.shiftDate);

    // 1️⃣ Try exact match
    let priceEntry = this.rpsPrice.find((item: any) => normalize(item.date) === entryDate);

    // 2️⃣ If not found, fallback to the latest available before entryDate
    if (!priceEntry) {
      const sorted = [...this.rpsPrice].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      priceEntry = sorted.find((item: any) => new Date(item.date) <= new Date(entryDate));
    }

    if (priceEntry) {
      entry.price = fuelCategory === 'MS'
        ? parseFloat(priceEntry.ms_rate) || 0
        : parseFloat(priceEntry.hsd_rate) || 0;

      console.log(`✅ Price for ${fuelCategory} on ${entryDate}: ${entry.price}`);
    } else {
      entry.price = 0;
      console.warn(`⚠️ No price found for ${fuelCategory} on or before ${entryDate}`);
    }
  }


  onDateChange1(event: any) {
    this.saveMessage = '';
    this.isSaveButtonVisible = true;
    this.postShiftA = false; // reset flag
    const selectedDate = event.target.value;
    console.log('Selected date:', selectedDate);

    const today = new Date();
    const allowedDate = new Date(today);
    allowedDate.setDate(today.getDate() - 1);

    const selected = new Date(selectedDate);
    const isAllowedDate = selected.toDateString() === allowedDate.toDateString();

    if (this.userRoles.includes(303)) {
      this.getPreviouseShiftEntrie(selectedDate);
    } else if (isAllowedDate) {
      this.getPreviouseShiftEntrie(selectedDate);
    } else {
      iziToast.error({
        message: 'Permission denied for this date',
        position: 'topRight'
      });
    }
  }
  onDateChange(event: any) {
    const selectedDate = event.target.value;
    this.selectedDate = selectedDate;
    this.getRpsprice(this.selectedDate, () => {

      [this.shiftA, this.shiftB].forEach(shift => {
        if (shift.entries && shift.entries.length > 0) {
          shift.entries.forEach(entry => {
            entry.shiftDate = selectedDate;
            //const fuelCategory = entry.fuelType.toUpperCase();
            //this.setFuelPrice(entry, fuelCategory);
          });
        }
      });

      const today = new Date();
      const allowedDate = new Date(today);
      allowedDate.setDate(today.getDate() - 1);
      const selected = new Date(selectedDate);
      const isAllowedDate = selected.toDateString() === allowedDate.toDateString();

      if (this.userRoles.includes(303) || isAllowedDate) {
        this.getPreviouseShiftEntrie(selectedDate);
      } else {
        iziToast.error({
          message: 'Permission denied for this date',
          position: 'topRight'
        });
      }
      if (this.isPumpSelectedA) {
        this.handlePumpSelection(
          Object.keys(this.pumpSelection),
          this.shiftA,
          'A',
          this.selectedDate
        );
      }

      if (this.isPumpSelectedB) {
        this.handlePumpSelection(
          Object.keys(this.pumpSelection),
          this.shiftB,
          'B',
          this.selectedDate
        );
      }
    });

    this.openApprovalPopup();
  }



  getPreviouseShiftEntrie(shiftKey: string) {

    const pump = this.shiftA.entries[0]?.pump || this.shiftB.entries[0]?.pump;
    const shift = this.shiftA.entries[0]?.shift || this.shiftB.entries[0]?.shift;

    if (!pump || !shift) {
      console.error('Pump or Shift are invalid!');
      return;
    }
    this.getShiftReadings(`pump${pump}-shift${shift === 'Shift 1' ? '1' : '2'}`);
    const user_id = localStorage.getItem('user_id');

    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "ShiftEntriesDetails",
      user_id,
      shift: shift,
      pump_no: pump,
      date: shiftKey,
    };
    console.log('Request data:', requestData);
    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        this.isLoading = false;

        if (response.status === true || response.status === 'true') {
          this.entry_id = response.data[0].id
          console.log('this.entry_id', this.entry_id);
          this.isDateReadonly = response.hint == 'date_readonly';
          console.log('this.isDateReadonly', this.isDateReadonly)
          if (response.data === 'yes') {
            // this.isPumpSelectedA = false;
            // this.isPumpSelectedB = false;
            this.isSaveButtonVisible = false;
            this.saveMessage = response.message;
            this.saveMessage = `Already saved this shift/pump entry for the selected date: ${shiftKey}`;
            this.postShiftA = false;
            this.postShiftB = false;
            iziToast.error({
              message: response.message,
              position: 'topRight'
            });
            //this.selectedPump = null;
            this.isLoading = false;
            return false;
          } else {
            const data = response.data[0];

            this.entry_id = data.id;
            this.isDateReadonly = response.hint === 'date_readonly';
            this.postShiftA = this.postShiftB = true;
            this.isSaveButtonVisible = true;
            const sharedFields = {
              shift: data.shift,
              pump: data.pump_no,
              operatorId: Number(data.operator_id) || 0,
              operatorName: data.operator_name || '',
              shiftfueltotal: Number(data.shift_fuel_total) || 0,
              shiftoilsales: Number(data.oil_sale) || 0,
              shiftdiscount: Number(data.discount) || 0,
              shifevtotal: Number(data.ev_total) || 0,
              shifttest: Number(data.test_fuel) || 0,
              shiftextrafuel: Number(data.extra_fuel) || 0,
              shiftcoins: Number(data.coins) || 0,

              shiftgpay: Number(data.gpay) || 0,
              shiftphonepe: Number(data.phonepe) || 0,
              shiftswiping: Number(data.swipping) || 0,
              shiftcash: Number(data.cash) || 0,
              shiftcredit: Number(data.credit) || 0,
              shifttotal: Number(data.payment_total) || 0,
              shiftreceipt: Number(data.receipt) || 0,
              shiftgrandtotal: Number(data.grand_total_1) || 0,
              ev_entry: data.ev_entry || 0,
              shiftgtotal: Number(data.grand_total_2) || 0,
              shiftdifference: Number(data.difference) || 0,
            };

            const fuelEntries: any[] = [];

            if (data.hsd_fuel_type) {
              fuelEntries.push({
                ...sharedFields,
                fuelType: data.hsd_fuel_type,
                opening: Number(data.hsd_opening_reading) || 0,
                closing: Number(data.hsd_closing_reading) || 0,
                sales: Number(data.hsd_total_sales) || 0,
                price: Number(data.hsd_price) || 0,
                total: Number(data.hsd_total_amount) || 0,
                testfuel: Number(data.hsd_test_liters) || 0,
                testfuelamoutnt: Number(data.hsd_test_amount) || 0,
                nozzle: data.shift === 'Shift 1' ? 'HSD1' : 'HSD2',
                errors: {}
              });
            }

            if (data.ms_fuel_type) {
              fuelEntries.push({
                ...sharedFields,
                fuelType: data.ms_fuel_type,

                opening: Number(data.ms_opening_reading) || 0,
                closing: Number(data.ms_closing_reading) || 0,
                sales: Number(data.ms_total_sales) || 0,
                price: Number(data.ms_price) || 0,
                total: Number(data.ms_total_amount) || 0,
                testfuel: Number(data.ms_test_liters) || 0,
                testfuelamoutnt: Number(data.ms_test_amount) || 0,
                nozzle: data.shift === 'Shift 1' ? 'MS1' : 'MS2',
                errors: {}
              });
              console.log('ms_fuel_type', data.nozzle);
            }

            const targetShift = data.shift === 'Shift 1' ? this.shiftA : this.shiftB;
            targetShift.entries = targetShift.entries || [];

            fuelEntries.forEach(entry => {
              const existingIndex = targetShift.entries.findIndex(e => e.fuelType === entry.fuelType);
              if (existingIndex >= 0) {
                Object.assign(targetShift.entries[existingIndex], entry);
              } else {
                targetShift.entries.push(entry);
              }
            });

            if (data.shift === 'Shift 1') {
              this.isPumpSelectedA = true;
            } else {
              this.isPumpSelectedB = true;
            }

            if (data.coins_denom) {
              const mapCoins = data.coins_denom.map((c: any) => ({ coins: c.denomination, count: c.quantity }));
              if (data.shift === 'Shift 1') {
                this.coinData = mapCoins;
                this.updateCoinTotal();
              } else {
                this.coinDataB = mapCoins;
                this.updateCoinTotalB();
              }
            }

            if (data.cash_denom) {
              const mapCash = data.cash_denom.map((c: any) => ({ cash: c.denomination, count: c.quantity }));
              if (data.shift === 'Shift 1') {
                this.cashList = mapCash;
                this.updateCashTotal();
              } else {
                this.cashListB = mapCash;
                this.updateCashTotalB();
              }
            }

            if (data.customer_credit) {
              const mapCust = data.customer_credit.map((cust: any) => ({
                id: cust.customer_id,
                name: cust.customer_name,
                customer_id: cust.customer_id,
                customer_name: cust.customer_name,
                selectedCustomer: { id: cust.customer_id, name: cust.customer_name },
                category: cust.fuel_type,
                liters: +cust.liters,
                vehicle: cust.vehicle_number,
                slip_no: cust.slip_no,
                rate: +cust.rate,
                customertotal: cust.total,
                maxLimit: Number(cust.credit_limit ?? 0),
                exceedsLimit: false,
                within_terms: true,
                allowed_credit: true
              }));
              if (data.shift === 'Shift 1') {
                this.creditCustomers = mapCust;
              } else {
                this.creditCustomersB = mapCust;
              }
            }

            if (data.product_entry) {
              if (data.shift === 'Shift 1') {
                this.products = data.product_entry;
              } else {
                this.productsB = data.product_entry;
              }
            }
          }
        } else {
          this.postShiftA = this.postShiftB = false;
          this.onPumpSelectedA(shiftKey);
          this.onPumpSelectedB(shiftKey);
          this.getCaseCoinType();
          this.creditCustomers = []
          this.creditCustomersB = []
          this.validateFieldsB = false;
          this.validateFieldsA = false;
        }
        this.isLoading = false;
        return true;
      },
      error: () => {
        this.isLoading = false;
      }
    });

  }
  getShiftReadings(shiftKey: string) {
    let [pump, shiftValue, fuel] = shiftKey.split('-');

    const pumpMap: Record<string, string> = { pump1: '1', pump2: '2' };
    pump = pumpMap[pump] || pump;

    const shiftMap: Record<string, string> = { shift1: 'Shift 1', shift2: 'Shift 2' };
    shiftValue = shiftMap[shiftValue] || shiftValue;

    this.isLoading = true;
    const user_id = localStorage.getItem('user_id');

    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "getShiftReadings",
      user_id,
      shift: shiftValue,
      // nozzle: fuel.toUpperCase(),
      pump_no: pump,
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {

        if (response.status === true || response.status === 'true') {
          const msOpening = parseFloat(response.data.ms_opening) || 0.00;
          const hsdOpening = parseFloat(response.data.hsd_opening) || 0.00;
          this.closingReading = response.data
          this.isOpeningReadonly = response.hint !== 'allow';
          console.log('this.isOpeningReadonly', this.isOpeningReadonly)
          this.setOpeningValue('A', msOpening, hsdOpening);
          this.setOpeningValue('B', msOpening, hsdOpening);

          //console.log('Updated shiftA.entries[0].opening:', this.shiftA.entries[0].opening);
          //console.log('Updated shiftB.entries[0].opening:', this.shiftB.entries[0].opening);
        }
        else {
          iziToast.error({
            message: response.message,
            position: 'topRight'
          });
        }

      },
    });
  }
  setOpeningValue(target: 'A' | 'B', msValue: number, hsdValue?: number) {
    const shift = target === 'A' ? this.shiftA : this.shiftB;

    // Ensure that the shift has entries
    if (!shift.entries || shift.entries.length === 0) {
      return;
    }


    // if (target === 'A') {
    //   shift.entries[0].opening = msValue;
    //   if (shift.entries.length > 1) {
    //     shift.entries[1].opening = hsdValue || msValue;
    //   }
    // } 

    // else if (target === 'B') {
    //   shift.entries[0].opening = msValue; 
    //   if (shift.entries.length > 1) {
    //     shift.entries[1].opening = hsdValue || msValue;
    //   }
    // }
    shift.entries[0].opening = msValue;


    if (shift.entries.length > 1) {
      shift.entries[1].opening = hsdValue || msValue || 0;
    }

    shift.entries.forEach(entry => entry.errors['opening'] = '');
  }

  formatDateToYMD(dateStr: string): string {
    const [day, month, year] = dateStr.split('-');
    return `${year}-${month}-${day}`;
  }
  openApprovalPopup() {
    const date = this.selectedDate ? new Date(this.selectedDate) : new Date();
    date.setDate(date.getDate() - 1);

    this.approvalDate = date.toISOString().split('T')[0];

    console.log(' this.approvalDate', this.approvalDate);
    // Set loading state
    this.isLoading = true;

    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: 'approval',
      api_type: 'api',
      api_url: 'approval_list',
      user_id: user_id,
      from_date: '',
      to_date: '',
      approval_name: ''
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        this.isLoading = false;

        if (response.status && response.data) {
          const alreadyApproved = response.data.some(
            (item: any) => this.formatDateToYMD(item.shift_date) === this.approvalDate
          );

          if (!alreadyApproved) {
            $('#showApprovalModal').modal({
              backdrop: 'static',
              keyboard: false,
              show: true
            });
            this.approvalAmount = 0;
            this.approval_list = []; // clear old list if needed
          } else {
            // Approval already exists for this date — DO NOT open popup
            console.info(`Approval already exists for ${this.approvalDate}`);
          }
        }
      },
      error: () => {
        this.isLoading = false;
        console.error('Failed to fetch approval list');
      }
    });
  }


  closeApprovalPopup() {
    $('#showApprovalModal').modal('hide');
    this.selectedPump = null;
    this.onCancelA();
    this.onCancelB();
  }
  saveApproval() {
    this.isLoading = true;
    const requestData = {
      moduleType: 'approval',
      api_type: 'api',
      api_url: 'approvalSave',
      user_id: '1',
      shift_date: this.approvalDate,
      amount: this.approvalAmount,
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        this.isLoading = false;
        if (response && response.data) {
          iziToast.success({
            message: 'approval Detail Sent Successfully',
            position: 'topRight'
          });
          this.closeApprovalPopup()
        } else {
          iziToast.error({
            message: response?.message || 'Failed to save a record',
            position: 'topRight'
          });
        }
      },
      error: (error: any) => {
        this.isLoading = false;
        console.error(error);
        iziToast.error({
          message: 'Network error while saving.',
          position: 'topRight'
        });
        this.closeApprovalPopup()
      }
    });

  }


  selectBoth(msKey: string, hsdKey: string, selectedDate?: string) {
    // Reset all pump selections
    Object.keys(this.pumpSelection).forEach(key => this.pumpSelection[key] = false);
    this.pumpSelection[msKey] = true;
    this.pumpSelection[hsdKey] = true;

    const [pump, shift] = msKey.split('-');

    this.shiftA.entries = [];
    this.shiftB.entries = [];
    const today = new Date().toISOString().split('T')[0];
    this.selectedDate = selectedDate || today;

    this.getRpsprice(this.selectedDate, () => {
      this.getTodayShiftEntrie(`${pump}-${shift}`);
    });
    this.openApprovalPopup();
    // Reset limits when selecting shifts
    this.resetLimitFlags();
  }



  getTodayShiftEntrie(shiftKey: string) {
    this.getShiftReadings(shiftKey);
    let [pump, shiftValue] = shiftKey.split('-');

    const pumpMap: Record<string, string> = { pump1: '1', pump2: '2' };
    pump = pumpMap[pump] || pump;

    const shiftMap: Record<string, string> = { shift1: 'Shift 1', shift2: 'Shift 2' };
    shiftValue = shiftMap[shiftValue] || shiftValue;

    this.isLoading = true;
    const user_id = localStorage.getItem('user_id');
    this.creditCustomers = [];
    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "todayShiftEntries",
      user_id,
      shift: shiftValue,
      pump_no: pump,
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        this.isLoading = false;

        if (response.status === true || response.status === 'true') {
          console.log("321")
          this.entry_id = response.data[0].id
          console.log('this.entry_id', this.entry_id);
          this.isDateReadonly = response.hint == 'date_readonly';
          console.log('this.isDateReadonly', this.isDateReadonly)
          if (response.data === 'yes') {
            // this.isPumpSelectedA = false;
            // this.isPumpSelectedB = false;
            this.isSaveButtonVisible = false;
            this.saveMessage = response.message;
            this.saveMessage = 'Already saved this shift/pump entry for today';
            this.postShiftA = false;
            this.postShiftB = false;
            iziToast.error({
              message: response.message,
              position: 'topRight'
            });
            //this.selectedPump = null;
            this.isLoading = false;
            return false;
          } else {
            const data = response.data[0];
            this.entry_id = data.id;
            this.isDateReadonly = response.hint === 'date_readonly';
            this.postShiftA = this.postShiftB = true;
            this.isSaveButtonVisible = true;
            this.saveMessage = '';
            const sharedFields = {
              shift: data.shift,
              pump: data.pump_no,
              operatorId: Number(data.operator_id) || 0,
              operatorName: data.operator_name || '',
              shiftfueltotal: Number(data.shift_fuel_total) || 0,
              shiftoilsales: Number(data.oil_sale) || 0,
              shiftdiscount: Number(data.discount) || 0,
              shifevtotal: Number(data.ev_total) || 0,
              shifttest: Number(data.test_fuel) || 0,
              shiftextrafuel: Number(data.extra_fuel) || 0,
              shiftcoins: Number(data.coins) || 0,
              shiftgpay: Number(data.gpay) || 0,
              shiftphonepe: Number(data.phonepe) || 0,
              shiftswiping: Number(data.swipping) || 0,
              shiftcash: Number(data.cash) || 0,
              shiftcredit: Number(data.credit) || 0,
              shifttotal: Number(data.payment_total) || 0,
              shiftreceipt: Number(data.receipt) || 0,
              shiftgrandtotal: Number(data.grand_total_1) || 0,
              ev_entry: data.ev_entry || 0,
              shiftgtotal: Number(data.grand_total_2) || 0,
              shiftdifference: Number(data.difference) || 0,
            };

            const fuelEntries: any[] = [];

            if (data.hsd_fuel_type) {
              fuelEntries.push({
                ...sharedFields,
                fuelType: data.hsd_fuel_type,
                opening: Number(data.hsd_opening_reading) || 0,
                closing: Number(data.hsd_closing_reading) || 0,
                sales: Number(data.hsd_total_sales) || 0,
                price: Number(data.hsd_price) || 0,
                total: Number(data.hsd_total_amount) || 0,
                testfuel: Number(data.hsd_test_liters) || 0,
                testfuelamoutnt: Number(data.hsd_test_amount) || 0,
                nozzle: data.shift === 'Shift 1' ? 'HSD1' : 'HSD2',
                errors: {}
              });
            }

            if (data.ms_fuel_type) {
              fuelEntries.push({
                ...sharedFields,
                fuelType: data.ms_fuel_type,

                opening: Number(data.ms_opening_reading) || 0,
                closing: Number(data.ms_closing_reading) || 0,
                sales: Number(data.ms_total_sales) || 0,
                price: Number(data.ms_price) || 0,
                total: Number(data.ms_total_amount) || 0,
                testfuel: Number(data.ms_test_liters) || 0,
                testfuelamoutnt: Number(data.ms_test_amount) || 0,
                nozzle: data.shift === 'Shift 1' ? 'MS1' : 'MS2',
                errors: {}
              });
              console.log('ms_fuel_type', data.nozzle);
            }

            const targetShift = data.shift === 'Shift 1' ? this.shiftA : this.shiftB;
            targetShift.entries = targetShift.entries || [];

            fuelEntries.forEach(entry => {
              const existingIndex = targetShift.entries.findIndex(e => e.fuelType === entry.fuelType);
              if (existingIndex >= 0) {
                Object.assign(targetShift.entries[existingIndex], entry);
              } else {
                targetShift.entries.push(entry);
              }
            });

            if (data.shift === 'Shift 1') {
              this.isPumpSelectedA = true;
            } else {
              this.isPumpSelectedB = true;
            }

            if (data.coins_denom) {
              const mapCoins = data.coins_denom.map((c: any) => ({ coins: c.denomination, count: c.quantity }));
              if (data.shift === 'Shift 1') {
                this.coinData = mapCoins;
                this.updateCoinTotal();
              } else {
                this.coinDataB = mapCoins;
                this.updateCoinTotalB();
              }
            }

            if (data.cash_denom) {
              const mapCash = data.cash_denom.map((c: any) => ({ cash: c.denomination, count: c.quantity }));
              if (data.shift === 'Shift 1') {
                this.cashList = mapCash;
                this.updateCashTotal();
              } else {
                this.cashListB = mapCash;
                this.updateCashTotalB();
              }
            }

            if (data.customer_credit) {
              const mapCust = data.customer_credit.map((cust: any) => ({
                id: cust.customer_id,
                name: cust.customer_name,
                customer_id: cust.customer_id,
                customer_name: cust.customer_name,
                selectedCustomer: { id: cust.customer_id, name: cust.customer_name },
                category: cust.fuel_type,
                liters: +cust.liters,
                vehicle: cust.vehicle_number,
                slip_no: cust.slip_no,
                rate: +cust.rate,
                customertotal: cust.total,
                maxLimit: Number(cust.credit_limit ?? 0),
                exceedsLimit: false,
                within_terms: true,
                allowed_credit: true
              }));
              if (data.shift === 'Shift 1') {
                this.creditCustomers = mapCust;
              } else {
                this.creditCustomersB = mapCust;
              }
            }

            if (data.product_entry) {
              if (data.shift === 'Shift 1') {
                this.products = data.product_entry;
              } else {
                this.productsB = data.product_entry;
              }
            }
          }
        } else {
          this.postShiftA = this.postShiftB = false;
          this.onPumpSelectedA(shiftKey);
          this.onPumpSelectedB(shiftKey);
          this.getCaseCoinType();
          this.coinGrandTotal = 0;
          this.creditCustomers = []
          this.creditCustomersB = []
          this.validateFieldsA = false;
          this.validateFieldsB = false;
        }
        this.isLoading = false;
        return true;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }



  // Public wrapper methods
  onPumpSelectedA(pumpKey: string,): void {

    // this.getRpsprice();
    this.saveMessage = '';
    this.isSaveButtonVisible = true;
    this.postShiftA = false; // reset flag
    this.isDateReadonly = false;
    // if (!this.rpsPrice || !this.rpsPrice.length) {
    if (!Array.isArray(this.rpsPrice) || this.rpsPrice.length === 0) {
      iziToast.error({
        message: this.rpsPriceMessage,
        position: 'topRight'
      });
      return;
    }

    const hasMS = this.rpsPrice.some(item => item.ms_rate);
    const hasHSD = this.rpsPrice.some(item => item.hsd_rate);

    if (hasMS && hasHSD) {
      if (pumpKey === 'pump1') {
        this.handlePumpSelection(['pump1-shift1-ms1', 'pump1-shift1-hsd1'], this.shiftA, 'A', this.selectedDate);
      }

      // Handle pump2
      if (pumpKey === 'pump2') {
        this.handlePumpSelection(['pump2-shift1-ms2', 'pump2-shift1-hsd2'], this.shiftA, 'A', this.selectedDate);
      }


    } else {

      if (!hasMS) {
        iziToast.error({
          message: 'Please add RPS record for MS today',
          position: 'topRight'
        });
      }
      if (!hasHSD) {

        iziToast.error({
          message: 'Please add RPS record for DSH today',
          position: 'topRight'
        });
      }
    }

  }


  onPumpSelectedB(pumpKey: string): void {
    // this.getRpsprice();
    this.saveMessage = '';
    this.isSaveButtonVisible = true;
    this.postShiftA = false;
    this.isDateReadonly = false;
    // if (!this.rpsPrice || !this.rpsPrice.length) {
    if (!Array.isArray(this.rpsPrice) || this.rpsPrice.length === 0) {
      iziToast.error({
        message: this.rpsPriceMessage,
        position: 'topRight'
      });
      return;
    }

    const hasMS = this.rpsPrice.some(item => item.ms_rate);
    const hasHSD = this.rpsPrice.some(item => item.hsd_rate);

    if (hasMS && hasHSD) {
      if (pumpKey === 'pump1') {
        this.handlePumpSelection(['pump1-shift2-ms1', 'pump1-shift2-hsd1'], this.shiftB, 'B', this.selectedDate);
      }

      // Handle pump2
      if (pumpKey === 'pump2') {
        this.handlePumpSelection(['pump2-shift2-ms2', 'pump2-shift2-hsd2'], this.shiftB, 'B', this.selectedDate);
      }
    } else {

      if (!hasMS) {
        iziToast.error({
          message: 'Please add RPS record for MS today',
          position: 'topRight'
        });
      }
      if (!hasHSD) {

        iziToast.error({
          message: 'Please add RPS record for DSH today',
          position: 'topRight'
        });
      }
    }
  }

  onShiftTabChange(shift: 'A' | 'B'): void {
    this.selectedPump = null;
    this.isPumpSelectedA = false;
    this.isPumpSelectedB = false;
    this.isDateReadonly = false;
    Object.keys(this.pumpSelection).forEach(key => {
      this.pumpSelection[key] = false;
    });
  }
  onCancelA() {
    Object.keys(this.pumpSelection).forEach(key => {
      this.pumpSelection[key] = false;
    });
    this.isPumpSelectedA = false;
    this.isDateReadonly = false;
  }
  onCancelB() {
    Object.keys(this.pumpSelection).forEach(key => {
      this.pumpSelection[key] = false;
    });
    this.isPumpSelectedB = false;
    this.isDateReadonly = false;
  }

  // Shift A Entry Decimal start
  getOpeningValue(entry: any, i: number): string {
    if (this.isOpeningFocusedIndex === i) {
      return entry.openingDisplay ?? '';
    }
    if (entry.openingDisplay !== undefined && entry.openingDisplay !== null && entry.openingDisplay !== '') {
      return entry.openingDisplay;
    }
    return entry.opening != null ? Number(entry.opening).toFixed(2) : '';
  }

  onOpeningFocus(i: number) {
    this.isOpeningFocusedIndex = i;
  }

  onOpeningInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.openingDisplay = '';
      entry.opening = 0;
      return;
    }
    entry.openingDisplay = value;
    entry.opening = this.parseNumber(value);
    this.updateSalesA(index);

    if (!isNaN(entry.opening) && entry.errors) {
      delete entry.errors['opening'];
    }
  }
  onOpeningBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isOpeningFocusedIndex = null;
    if (entry.openingDisplay === '' || entry.opening == null) {
      entry.opening = 0;
      entry.openingDisplay = '0.00';
    } else {
      entry.opening = this.formatToTwoDecimals(entry.opening || 0);
      entry.openingDisplay = entry.opening.toFixed(2);
    }
    this.updateSalesA(index);
  }

  getClosingValue(entry: any, i: number): string {
    if (this.isClosingFocusedIndex === i) {
      return entry.closingDisplay ?? '';
    }
    if (entry.closingDisplay !== undefined && entry.closingDisplay !== null && entry.closingDisplay !== '') {
      return entry.closingDisplay;
    }
    return entry.closing != null ? Number(entry.closing).toFixed(2) : '';
  }

  onClosingFocus(i: number) {
    this.isClosingFocusedIndex = i;
  }

  onClosingInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.closingDisplay = '';
      entry.closing = 0;
      return;
    }

    entry.closingDisplay = value;
    entry.closing = this.parseNumber(value);
    this.updateSalesA(index);

    if (!isNaN(entry.sales) && entry.sales !== null && entry.sales !== undefined) {
      if (entry.errors) {
        delete entry.errors['sales'];
      }
    }
    if (!isNaN(entry.closing) && entry.closing !== null && entry.closing !== undefined) {
      if (entry.errors) {
        delete entry.errors['closing'];
      }
    }
  }

  onClosingBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isOpeningFocusedIndex = null;
    if (entry.closingDisplay === '' || entry.closing == null) {
      entry.closing = 0;
      entry.closingDisplay = '0.00';
    } else {
      entry.closing = this.formatToTwoDecimals(entry.closing || 0);
      entry.closingDisplay = entry.closing.toFixed(2);
    }

    this.updateSalesA(index);
  }

  getTestFuelValue(entry: any, i: number): string {
    if (this.isTestFuelFocusedIndex === i) {
      return entry.testfuelDisplay ?? '';
    }
    if (entry.testfuelDisplay !== undefined && entry.testfuelDisplay !== null && entry.testfuelDisplay !== '') {
      return entry.testfuelDisplay;
    }
    return entry.testfuel != null ? Number(entry.testfuel).toFixed(2) : '';
  }

  onTestFuelFocus(i: number) {
    this.isTestFuelFocusedIndex = i;
  }

  onTestFuelInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.testfuelDisplay = '';
      entry.testfuel = 0;
      return;
    }

    entry.testfuelDisplay = value;
    entry.testfuel = this.parseNumber(value);
    this.updateSalesA(index);
  }

  onTestFuelBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isTestFuelFocusedIndex = null;
    if (entry.testfuelDisplay === '' || entry.testfuel == null) {
      entry.testfuel = 0;
      entry.testfuelDisplay = '0.00';
    } else {
      entry.testfuel = this.formatToTwoDecimals(entry.testfuel || 0);
      entry.testfuelDisplay = entry.testfuel.toFixed(2);
    }

    this.updateSalesA(index);
  }

  getshiftgpayValue(entry: any, index: number): string {
    // while focused, let user see exactly what they typed (including empty)
    if (this.isShiftgpayFocusedIndex === index) {
      return entry.shiftgpayDisplay ?? '';
    }

    // not focused: show formatted value if available
    if (entry.shiftgpayDisplay !== undefined && entry.shiftgpayDisplay !== null && entry.shiftgpayDisplay !== '') {
      return entry.shiftgpayDisplay;
    }

    return entry.shiftgpay != null ? Number(entry.shiftgpay).toFixed(2) : '';
  }

  onshiftgpayFocus(index: number) {
    this.isShiftgpayFocusedIndex = index;
  }

  onshiftgpayInput(value: string, index: number) {
    const entry = this.shiftA.entries[index];

    if (value === '') {
      entry.shiftgpayDisplay = '';
      entry.shiftgpay = 0;
      return;
    }

    entry.shiftgpayDisplay = value;
    entry.shiftgpay = this.parseNumber(value);
    this.calculateTotalsA();
  }

  onshiftgpayBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isShiftgpayFocusedIndex = null;

    if (entry.shiftgpayDisplay === '' || entry.shiftgpay == null) {
      entry.shiftgpay = 0;
      entry.shiftgpayDisplay = '0.00';
    } else {
      entry.shiftgpay = this.formatToTwoDecimals(entry.shiftgpay || 0);
      entry.shiftgpayDisplay = entry.shiftgpay.toFixed(2);
    }
  }

  getshiftphonepeValue(entry: any, index: number): string {
    if (this.isShiftphonepeFocusedIndex === index) {
      return entry.shiftphonepeDisplay ?? '';
    }
    if (entry.shiftphonepeDisplay !== undefined && entry.shiftphonepeDisplay !== null && entry.shiftphonepeDisplay !== '') {
      return entry.shiftphonepeDisplay;
    }
    return entry.shiftphonepe != null ? Number(entry.shiftphonepe).toFixed(2) : '';
  }

  onshiftphonepeFocus(index: number) {
    this.isShiftphonepeFocusedIndex = index;
  }

  onshiftphonepeInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.shiftphonepeDisplay = '';
      entry.shiftphonepe = 0;
      return;
    }

    entry.shiftphonepeDisplay = value;
    entry.shiftphonepe = this.parseNumber(value);
    this.calculateTotalsA();
  }

  onshiftphonepeBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isShiftphonepeFocusedIndex = null;
    if (entry.shiftphonepeDisplay === '' || entry.shiftphonepe == null) {
      entry.shiftphonepe = 0;
      entry.shiftphonepeDisplay = '0.00';
    } else {
      entry.shiftphonepe = this.formatToTwoDecimals(entry.shiftphonepe || 0);
      entry.shiftphonepeDisplay = entry.shiftphonepe.toFixed(2);
    }
    this.calculateTotalsA();
  }

  getshiftswipingValue(entry: any, index: number): string {
    if (this.isShiftswipingFocusedIndex === index) {
      return entry.shiftswipingDisplay ?? '';
    }
    if (entry.shiftswipingDisplay !== undefined && entry.shiftswipingDisplay !== null && entry.shiftswipingDisplay !== '') {
      return entry.shiftswipingDisplay;
    }
    return entry.shiftswiping != null ? Number(entry.shiftswiping).toFixed(2) : '';
  }

  onshiftswipingFocus(index: number) {
    this.isShiftswipingFocusedIndex = index;
  }

  onshiftswipingInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.shiftswipingDisplay = '';
      entry.shiftswiping = 0;
      return;
    }

    entry.shiftswipingDisplay = value;
    entry.shiftswiping = this.parseNumber(value);
    this.calculateTotalsA();
  }

  onshiftswipingBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isShiftswipingFocusedIndex = null;
    if (entry.shiftswipingDisplay === '' || entry.shiftswiping == null) {
      entry.shiftswiping = 0;
      entry.shiftswipingDisplay = '0.00';
    } else {
      entry.shiftswiping = this.formatToTwoDecimals(entry.shiftswiping || 0);
      entry.shiftswipingDisplay = entry.shiftswiping.toFixed(2);
    }
    this.calculateTotalsA();
  }


  getshiftreceiptValue(entry: any, index: number): string {
    if (this.isShiftreceiptFocusedIndex === index) {
      return entry.shiftreceiptDisplay ?? '';
    }
    if (entry.shiftreceiptDisplay !== undefined && entry.shiftreceiptDisplay !== null && entry.shiftreceiptDisplay !== '') {
      return entry.shiftreceiptDisplay;
    }
    return entry.shiftreceipt != null ? Number(entry.shiftreceipt).toFixed(2) : '';
  }

  onshiftreceiptFocus(index: number) {
    this.isShiftreceiptFocusedIndex = index;
  }

  onshiftreceiptInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.shiftreceiptDisplay = '';
      entry.shiftreceipt = 0;
      return;
    }

    entry.shiftreceiptDisplay = value;
    entry.shiftreceipt = this.parseNumber(value);
    this.calculateTotalsA();
  }

  onshiftreceiptBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isShiftreceiptFocusedIndex = null;
    if (entry.shiftreceiptDisplay === '' || entry.shiftreceipt == null) {
      entry.shiftreceipt = 0;
      entry.shiftreceiptDisplay = '0.00';
    } else {
      entry.shiftreceipt = this.formatToTwoDecimals(entry.shiftreceipt || 0);
      entry.shiftreceiptDisplay = entry.shiftreceipt.toFixed(2);
    }
    this.calculateTotalsA();
  }


  getshiftdiscountValue(entry: any, index: number): string {
    if (this.isShiftdiscountFocusedIndex === index) {
      return entry.shiftdiscountDisplay ?? '';
    }
    if (entry.shiftdiscountDisplay !== undefined && entry.shiftdiscountDisplay !== null && entry.shiftdiscountDisplay !== '') {
      return entry.shiftdiscountDisplay;
    }
    return entry.shiftdiscount != null ? Number(entry.shiftdiscount).toFixed(2) : '';
  }

  onshiftdiscountFocus(index: number) {
    this.isShiftdiscountFocusedIndex = index;
  }

  onshiftdiscountInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.shiftdiscountDisplay = '';
      entry.shiftdiscount = 0;
      return;
    }

    entry.shiftdiscountDisplay = value;
    entry.shiftdiscount = this.parseNumber(value);
    this.calculateTotalsA();
  }

  onshiftdiscountBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isShiftdiscountFocusedIndex = null;
    if (entry.shiftdiscountDisplay === '' || entry.shiftdiscount == null) {
      entry.shiftdiscount = 0;
      entry.shiftdiscountDisplay = '0.00';
    } else {
      entry.shiftdiscount = this.formatToTwoDecimals(entry.shiftdiscount || 0);
      entry.shiftdiscountDisplay = entry.shiftdiscount.toFixed(2);
    }
    this.calculateTotalsA();
  }

  getshiftextrafuelValue(entry: any, index: number): string {
    if (this.isShiftextrafuelFocusedIndex === index) {
      return entry.shiftextrafuelDisplay ?? '';
    }
    if (entry.shiftextrafuelDisplay !== undefined && entry.shiftextrafuelDisplay !== null && entry.shiftextrafuelDisplay !== '') {
      return entry.shiftextrafuelDisplay;
    }
    return entry.shiftextrafuel != null ? Number(entry.shiftextrafuel).toFixed(2) : '';
  }

  onshiftextrafuelFocus(index: number) {
    this.isShiftextrafuelFocusedIndex = index;
  }

  onshiftextrafuelInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.shiftextrafuelDisplay = '';
      entry.shiftextrafuel = 0;
      return;
    }

    entry.shiftextrafuelDisplay = value;
    entry.shiftextrafuel = this.parseNumber(value);
    this.calculateTotalsA();
  }

  onshiftextrafuelBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isShiftextrafuelFocusedIndex = null;
    if (entry.shiftextrafuelDisplay === '' || entry.shiftextrafuel == null) {
      entry.shiftextrafuel = 0;
      entry.shiftextrafuelDisplay = '0.00';
    } else {
      entry.shiftextrafuel = this.formatToTwoDecimals(entry.shiftextrafuel || 0);
      entry.shiftextrafuelDisplay = entry.shiftextrafuel.toFixed(2);
    }
    this.calculateTotalsA();
  }

  getshiftmanualdifferenceValue(entry: any, index: number): string {
    if (this.isshiftmanualdifferenceFocusedIndex === index) {
      return entry.shiftmanualdifferenceDisplay ?? '';
    }
    if (entry.shiftmanualdifferenceDisplay !== undefined && entry.shiftmanualdifferenceDisplay !== null && entry.shiftmanualdifferenceDisplay !== '') {
      return entry.shiftmanualdifferenceDisplay;
    }
    return entry.shiftmanualdifference != null ? Number(entry.shiftmanualdifference).toFixed(2) : '';
  }

  onshiftmanualdifferenceFocus(index: number) {
    this.isshiftmanualdifferenceFocusedIndex = index;
  }

  onshiftmanualdifferenceInput(value: string, index: number): void {
    const entry = this.shiftA.entries[index];
    if (value === '') {
      entry.shiftmanualdifferenceDisplay = '';
      entry.shiftmanualdifference = 0;
      return;
    }

    entry.shiftmanualdifferenceDisplay = value;
    entry.shiftmanualdifference = this.parseNumber(value);
  }

  onshiftmanualdifferenceBlur(index: number) {
    const entry = this.shiftA.entries[index];
    this.isshiftmanualdifferenceFocusedIndex = null;
    if (entry.shiftmanualdifferenceDisplay === '' || entry.shiftmanualdifference == null) {
      entry.shiftmanualdifference = 0;
      entry.shiftmanualdifferenceDisplay = '0.00';
    } else {
      entry.shiftmanualdifference = this.formatToTwoDecimals(entry.shiftmanualdifference || 0);
      entry.shiftmanualdifferenceDisplay = entry.shiftmanualdifference.toFixed(2);
    }
  }
  // Shift A Entry Decimal End

  // Shift B Entry Decimal start
  getOpeningValueB(entry: any, i: number): string {
    if (this.isOpeningFocusedIndex === i) {
      return entry.openingDisplay ?? '';
    }
    if (entry.openingDisplay !== undefined && entry.openingDisplay !== null && entry.openingDisplay !== '') {
      return entry.openingDisplay;
    }
    return entry.opening != null ? Number(entry.opening).toFixed(2) : '';
  }

  onOpeningFocusB(i: number) {
    this.isOpeningFocusedIndex = i;
  }

  onOpeningInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.openingDisplay = '';
      entry.opening = 0;
      return;
    }
    entry.openingDisplay = value;
    entry.opening = this.parseNumber(value);
    this.updateSalesB(index);

    if (!isNaN(entry.opening) && entry.errors) {
      delete entry.errors['opening'];
    }
  }
  onOpeningBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isOpeningFocusedIndex = null;
    if (entry.openingDisplay === '' || entry.opening == null) {
      entry.opening = 0;
      entry.openingDisplay = '0.00';
    } else {
      entry.opening = this.formatToTwoDecimals(entry.opening || 0);
      entry.openingDisplay = entry.opening.toFixed(2);
    }
    this.updateSalesB(index);
  }

  getClosingValueB(entry: any, i: number): string {
    if (this.isClosingFocusedIndex === i) {
      return entry.closingDisplay ?? '';
    }
    if (entry.closingDisplay !== undefined && entry.closingDisplay !== null && entry.closingDisplay !== '') {
      return entry.closingDisplay;
    }
    return entry.closing != null ? Number(entry.closing).toFixed(2) : '';
  }

  onClosingFocusB(i: number) {
    this.isClosingFocusedIndex = i;
  }

  onClosingInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.closingDisplay = '';
      entry.closing = 0;
      return;
    }

    entry.closingDisplay = value;
    entry.closing = this.parseNumber(value);
    this.updateSalesB(index);

    if (!isNaN(entry.sales) && entry.sales !== null && entry.sales !== undefined) {
      if (entry.errors) {
        delete entry.errors['sales'];
      }
    }
    if (!isNaN(entry.closing) && entry.closing !== null && entry.closing !== undefined) {
      if (entry.errors) {
        delete entry.errors['closing'];
      }
    }
  }

  onClosingBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isOpeningFocusedIndex = null;
    if (entry.closingDisplay === '' || entry.closing == null) {
      entry.closing = 0;
      entry.closingDisplay = '0.00';
    } else {
      entry.closing = this.formatToTwoDecimals(entry.closing || 0);
      entry.closingDisplay = entry.closing.toFixed(2);
    }

    this.updateSalesB(index);
  }

  getTestFuelValueB(entry: any, i: number): string {
    if (this.isTestFuelFocusedIndex === i) {
      return entry.testfuelDisplay ?? '';
    }
    if (entry.testfuelDisplay !== undefined && entry.testfuelDisplay !== null && entry.testfuelDisplay !== '') {
      return entry.testfuelDisplay;
    }
    return entry.testfuel != null ? Number(entry.testfuel).toFixed(2) : '';
  }

  onTestFuelFocusB(i: number) {
    this.isTestFuelFocusedIndex = i;
  }

  onTestFuelInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.testfuelDisplay = '';
      entry.testfuel = 0;
      return;
    }

    entry.testfuelDisplay = value;
    entry.testfuel = this.parseNumber(value);
    this.updateSalesB(index);
  }

  onTestFuelBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isTestFuelFocusedIndex = null;
    if (entry.testfuelDisplay === '' || entry.testfuel == null) {
      entry.testfuel = 0;
      entry.testfuelDisplay = '0.00';
    } else {
      entry.testfuel = this.formatToTwoDecimals(entry.testfuel || 0);
      entry.testfuelDisplay = entry.testfuel.toFixed(2);
    }

    this.updateSalesB(index);
  }

  getshiftgpayValueB(entry: any, index: number): string {
    // while focused, let user see exactly what they typed (including empty)
    if (this.isShiftgpayFocusedIndex === index) {
      return entry.shiftgpayDisplay ?? '';
    }

    // not focused: show formatted value if available
    if (entry.shiftgpayDisplay !== undefined && entry.shiftgpayDisplay !== null && entry.shiftgpayDisplay !== '') {
      return entry.shiftgpayDisplay;
    }

    return entry.shiftgpay != null ? Number(entry.shiftgpay).toFixed(2) : '';
  }

  onshiftgpayFocusB(index: number) {
    this.isShiftgpayFocusedIndex = index;
  }

  onshiftgpayInputB(value: string, index: number) {
    const entry = this.shiftB.entries[index];

    if (value === '') {
      entry.shiftgpayDisplay = '';
      entry.shiftgpay = 0;
      return;
    }

    entry.shiftgpayDisplay = value;
    entry.shiftgpay = this.parseNumber(value);
    this.calculateTotalsB();
  }

  onshiftgpayBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isShiftgpayFocusedIndex = null;

    if (entry.shiftgpayDisplay === '' || entry.shiftgpay == null) {
      entry.shiftgpay = 0;
      entry.shiftgpayDisplay = '0.00';
    } else {
      entry.shiftgpay = this.formatToTwoDecimals(entry.shiftgpay || 0);
      entry.shiftgpayDisplay = entry.shiftgpay.toFixed(2);
    }
  }

  getshiftphonepeValueB(entry: any, index: number): string {
    if (this.isShiftphonepeFocusedIndex === index) {
      return entry.shiftphonepeDisplay ?? '';
    }
    if (entry.shiftphonepeDisplay !== undefined && entry.shiftphonepeDisplay !== null && entry.shiftphonepeDisplay !== '') {
      return entry.shiftphonepeDisplay;
    }
    return entry.shiftphonepe != null ? Number(entry.shiftphonepe).toFixed(2) : '';
  }

  onshiftphonepeFocusB(index: number) {
    this.isShiftphonepeFocusedIndex = index;
  }

  onshiftphonepeInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.shiftphonepeDisplay = '';
      entry.shiftphonepe = 0;
      return;
    }

    entry.shiftphonepeDisplay = value;
    entry.shiftphonepe = this.parseNumber(value);
    this.calculateTotalsB();
  }

  onshiftphonepeBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isShiftphonepeFocusedIndex = null;
    if (entry.shiftphonepeDisplay === '' || entry.shiftphonepe == null) {
      entry.shiftphonepe = 0;
      entry.shiftphonepeDisplay = '0.00';
    } else {
      entry.shiftphonepe = this.formatToTwoDecimals(entry.shiftphonepe || 0);
      entry.shiftphonepeDisplay = entry.shiftphonepe.toFixed(2);
    }
    this.calculateTotalsB();
  }

  getshiftswipingValueB(entry: any, index: number): string {
    if (this.isShiftswipingFocusedIndex === index) {
      return entry.shiftswipingDisplay ?? '';
    }
    if (entry.shiftswipingDisplay !== undefined && entry.shiftswipingDisplay !== null && entry.shiftswipingDisplay !== '') {
      return entry.shiftswipingDisplay;
    }
    return entry.shiftswiping != null ? Number(entry.shiftswiping).toFixed(2) : '';
  }

  onshiftswipingFocusB(index: number) {
    this.isShiftswipingFocusedIndex = index;
  }

  onshiftswipingInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.shiftswipingDisplay = '';
      entry.shiftswiping = 0;
      return;
    }

    entry.shiftswipingDisplay = value;
    entry.shiftswiping = this.parseNumber(value);
    this.calculateTotalsB();
  }

  onshiftswipingBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isShiftswipingFocusedIndex = null;
    if (entry.shiftswipingDisplay === '' || entry.shiftswiping == null) {
      entry.shiftswiping = 0;
      entry.shiftswipingDisplay = '0.00';
    } else {
      entry.shiftswiping = this.formatToTwoDecimals(entry.shiftswiping || 0);
      entry.shiftswipingDisplay = entry.shiftswiping.toFixed(2);
    }
    this.calculateTotalsB();
  }


  getshiftreceiptValueB(entry: any, index: number): string {
    if (this.isShiftreceiptFocusedIndex === index) {
      return entry.shiftreceiptDisplay ?? '';
    }
    if (entry.shiftreceiptDisplay !== undefined && entry.shiftreceiptDisplay !== null && entry.shiftreceiptDisplay !== '') {
      return entry.shiftreceiptDisplay;
    }
    return entry.shiftreceipt != null ? Number(entry.shiftreceipt).toFixed(2) : '';
  }

  onshiftreceiptFocusB(index: number) {
    this.isShiftreceiptFocusedIndex = index;
  }

  onshiftreceiptInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.shiftreceiptDisplay = '';
      entry.shiftreceipt = 0;
      return;
    }

    entry.shiftreceiptDisplay = value;
    entry.shiftreceipt = this.parseNumber(value);
    this.calculateTotalsB();
  }

  onshiftreceiptBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isShiftreceiptFocusedIndex = null;
    if (entry.shiftreceiptDisplay === '' || entry.shiftreceipt == null) {
      entry.shiftreceipt = 0;
      entry.shiftreceiptDisplay = '0.00';
    } else {
      entry.shiftreceipt = this.formatToTwoDecimals(entry.shiftreceipt || 0);
      entry.shiftreceiptDisplay = entry.shiftreceipt.toFixed(2);
    }
    this.calculateTotalsB();
  }


  getshiftdiscountValueB(entry: any, index: number): string {
    if (this.isShiftdiscountFocusedIndex === index) {
      return entry.shiftdiscountDisplay ?? '';
    }
    if (entry.shiftdiscountDisplay !== undefined && entry.shiftdiscountDisplay !== null && entry.shiftdiscountDisplay !== '') {
      return entry.shiftdiscountDisplay;
    }
    return entry.shiftdiscount != null ? Number(entry.shiftdiscount).toFixed(2) : '';
  }

  onshiftdiscountFocusB(index: number) {
    this.isShiftdiscountFocusedIndex = index;
  }

  onshiftdiscountInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.shiftdiscountDisplay = '';
      entry.shiftdiscount = 0;
      return;
    }

    entry.shiftdiscountDisplay = value;
    entry.shiftdiscount = this.parseNumber(value);
    this.calculateTotalsB();
  }

  onshiftdiscountBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isShiftdiscountFocusedIndex = null;
    if (entry.shiftdiscountDisplay === '' || entry.shiftdiscount == null) {
      entry.shiftdiscount = 0;
      entry.shiftdiscountDisplay = '0.00';
    } else {
      entry.shiftdiscount = this.formatToTwoDecimals(entry.shiftdiscount || 0);
      entry.shiftdiscountDisplay = entry.shiftdiscount.toFixed(2);
    }
    this.calculateTotalsB();
  }

  getshiftextrafuelValueB(entry: any, index: number): string {
    if (this.isShiftextrafuelFocusedIndex === index) {
      return entry.shiftextrafuelDisplay ?? '';
    }
    if (entry.shiftextrafuelDisplay !== undefined && entry.shiftextrafuelDisplay !== null && entry.shiftextrafuelDisplay !== '') {
      return entry.shiftextrafuelDisplay;
    }
    return entry.shiftextrafuel != null ? Number(entry.shiftextrafuel).toFixed(2) : '';
  }

  onshiftextrafuelFocusB(index: number) {
    this.isShiftextrafuelFocusedIndex = index;
  }

  onshiftextrafuelInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.shiftextrafuelDisplay = '';
      entry.shiftextrafuel = 0;
      return;
    }

    entry.shiftextrafuelDisplay = value;
    entry.shiftextrafuel = this.parseNumber(value);
    this.calculateTotalsB();
  }

  onshiftextrafuelBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isShiftextrafuelFocusedIndex = null;
    if (entry.shiftextrafuelDisplay === '' || entry.shiftextrafuel == null) {
      entry.shiftextrafuel = 0;
      entry.shiftextrafuelDisplay = '0.00';
    } else {
      entry.shiftextrafuel = this.formatToTwoDecimals(entry.shiftextrafuel || 0);
      entry.shiftextrafuelDisplay = entry.shiftextrafuel.toFixed(2);
    }
    this.calculateTotalsB();
  }

  getshiftmanualdifferenceValueB(entry: any, index: number): string {
    if (this.isshiftmanualdifferenceFocusedIndex === index) {
      return entry.shiftmanualdifferenceDisplay ?? '';
    }
    if (entry.shiftmanualdifferenceDisplay !== undefined && entry.shiftmanualdifferenceDisplay !== null && entry.shiftmanualdifferenceDisplay !== '') {
      return entry.shiftmanualdifferenceDisplay;
    }
    return entry.shiftmanualdifference != null ? Number(entry.shiftmanualdifference).toFixed(2) : '';
  }

  onshiftmanualdifferenceFocusB(index: number) {
    this.isshiftmanualdifferenceFocusedIndex = index;
  }

  onshiftmanualdifferenceInputB(value: string, index: number): void {
    const entry = this.shiftB.entries[index];
    if (value === '') {
      entry.shiftmanualdifferenceDisplay = '';
      entry.shiftmanualdifference = 0;
      return;
    }

    entry.shiftmanualdifferenceDisplay = value;
    entry.shiftmanualdifference = this.parseNumber(value);
  }

  onshiftmanualdifferenceBlurB(index: number) {
    const entry = this.shiftB.entries[index];
    this.isshiftmanualdifferenceFocusedIndex = null;
    if (entry.shiftmanualdifferenceDisplay === '' || entry.shiftmanualdifference == null) {
      entry.shiftmanualdifference = 0;
      entry.shiftmanualdifferenceDisplay = '0.00';
    } else {
      entry.shiftmanualdifference = this.formatToTwoDecimals(entry.shiftmanualdifference || 0);
      entry.shiftmanualdifferenceDisplay = entry.shiftmanualdifference.toFixed(2);
    }
  }

  parseNumber(value: string): number {
    const parsed = parseFloat(value.replace(/[^0-9.]/g, ''));
    return isNaN(parsed) ? 0 : parsed;
  }

  formatToTwoDecimals(value: number): number {
    return parseFloat(value.toFixed(2));
  }


}
