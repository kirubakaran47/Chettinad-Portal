import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, AbstractControl, Validators, ValidationErrors } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Server } from '../server';
import iziToast from 'izitoast';
import Swal from 'sweetalert2';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-shift-entry-list',
  imports: [CommonModule, FormsModule, RouterModule, ReactiveFormsModule, NgSelectModule, MatTooltipModule],
  templateUrl: './shift-entry-list.html',
  styleUrl: './shift-entry-list.css'
})
export class ShiftEntryList implements OnInit {
 validateFields: boolean = false;
  isLoading = false;
  operators: any;
  shift_entrt_list: any[] = [];
  errorMessage: string = '';
  limit: string = '10';
  offset: string = '0';
  vendorId: string | null = null;
  keyword: string = '';
  fromDate: string = '';
  toDate: string = '';
    hint: string = '';
  shiftA = {
    entries: [{
      shiftDate: '',
      pump: '',
      shift: '',
      nozzle: '',
      fuelType: '',
      opening: 0,
      closing: 0,
      sales: 0,
      operatorId: 0,
      operatorName: '',
      price: 0,
      testfuel: 0,
      testfuelamoutnt: 0,
      total: 0,
      shiftcoins: 0,
      shiftgpay: 0,
      shiftphonepe: 0,
      shiftswiping: 0,
      shiftcash: 0,
      shiftcredit: 0,
      shifttotal: 0,
      shiftreceipt: 0,
      shiftgrandtotal: 0,
      shiftfueltotal: 0,
      shifttest: 0,
      shiftoilsales: 0,
      shifevtotal: 0,
      shiftdiscount: 0,
      shiftextrafuel: 0,
      shiftgtotal: 0,
      shiftdifference: 0,
      shiftmanualdifference: 0,
      ms_fuel_type: 'MS',
      ms_opening_reading: 0,
      ms_closing_reading: 0,
      ms_total_sales: 0,
      ms_price: 0,
      ms_test_liters: 0,
      ms_test_amount: 0,
      ms_total_amount: 0,

      hsd_fuel_type: 'HSD',
      hsd_opening_reading: 0,
      hsd_closing_reading: 0,
      hsd_total_sales: 0,
      hsd_price: 0,
      hsd_test_liters: 0,
      hsd_test_amount: 0,
      hsd_total_amount: 0,
      ev_entry: [{ ev_hours: 0, rate: 0, total: 0 }],
      errors: {} as Record<string, string>
    }],
  };

  shiftB = {
    entries: [{
      shiftDate: '',
      pump: '',
      shift: '',
      fuelType: '',
      opening: 0,
      closing: 0,
      sales: 0,
      operatorName: '',
      price: 0,
      total: 0,
      shiftcoins: 0,
      shiftgpay: 0,
      shiftphonepe: 0,
      shiftswiping: 0,
      shiftcash: 0,
      shiftcredit: 0,
      shifttotal: 0,
      shiftreceipt: 0,
      shiftgrandtotal: 0,
      shiftfueltotal: 0,
      shifttest: 0,
      shiftoilsales: 0,
      shiftdiscount: 0,
      shiftextrafuel: 0,
      shiftgtotal: 0,
      shiftdifference: 0,
      shiftmanualdifference:0,
      ev_entry: [{ ev_hours: 0, rate: 0, total: 0 }],
      errors: {} as Record<string, string>
    }],
  };
  shiftSummaryData: any;

  isViewModalOpen: boolean = false;

  selectedDate: string = '';
  viewData: any = {};
  userRoles: number[] = [];
  editData: any;

  constructor(private serverService: Server, private http: HttpClient, private router: Router) {

  }

  ngOnInit() {
    this.getOperator();
    this.getCaseCoinType();
    this.shiftEntryListData();
    const rolesString = localStorage.getItem('roles');
    this.userRoles = rolesString ? JSON.parse(rolesString) : [];

  }
  home() {
    this.router.navigate(['/dashboard']);
  }
  getOperator(keyword: string = ''): void {
    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'get_operators',
      user_id: user_id,
      keyword: keyword,
    };
    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        // Check if the response contains the operator list and assign it to operators
        if (response && response.operator_list) {
          this.operators = response.operator_list.map((op: any) => ({
            id: op.user_id,
            name: op.full_name
          }));
        }
      },
      error: (err) => {
        console.error('Error fetching operators:', err);
      }
    });
  }

  onOperatorChange(selected: any, index: number) {
    if (selected) {
      this.shiftA.entries[index].operatorId = selected.id;
      this.shiftA.entries[index].operatorName = selected.name;
      // console.log('Operator selected:', selected.id, selected.name);
    } else {
      this.shiftA.entries[index].operatorId = 0;
      this.shiftA.entries[index].operatorName = '';
      // console.log('Operator cleared');
    }
  }
  onSearchChange(event: any): void {
    this.keyword = event.term;
    this.getOperator(this.keyword);
  }

  clearError(entryIndex: number, fieldName: string) {
    if (this.shiftA.entries[entryIndex].errors?.[fieldName]) {
      delete this.shiftA.entries[entryIndex].errors[fieldName];
    }
    if (this.shiftB.entries[entryIndex].errors?.[fieldName]) {
      delete this.shiftB.entries[entryIndex].errors[fieldName];
    }
  }

  shiftEntryListData() {
    this.isLoading = true;

    var formDate = $('#filterfromDate').val();
    var toDate = $('#filterToDate').val();
    var shiftNo = $('#filterShift').val();
    var operatorId = this.shiftA.entries[0].operatorId == 0 ? '' : this.shiftA.entries[0].operatorId;
    var fuleType = $('#filterFuel').val();
    var pumpNo = $('#filterPump').val();

    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'shiftreport',
      user_id: user_id,
      from_date: formDate,
      to_date: toDate,
      nozzle: pumpNo,
      shift_no: shiftNo,
      fuel_type: fuleType,
      operator_name: operatorId
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        if (response.status && response.data) {

          this.shift_entrt_list = response.data;
          const table = $('#datatable').DataTable();
          table.destroy();
          this.isLoading = false;

          setTimeout(() => {
            $('#datatable').DataTable();
          }, 0);
        }
      }
    });
  }

  // //////////////////////////////////////////////////////////////  edit /////////////////////////////////////////////////////////////

  shiftEntryId: any;
  shiftEntryName: any;
  coinData: any[] = [];
  cashList: any[] = [];
  products: any[] = [];
  allOilProducts: any[] = [];
  creditCustomers: any[] = [];
  customerOptions: any[] = [];
  coinGrandTotal = 0;
  cashGrandTotal = 0;
  coinCollapseVisible: boolean = false;
  cashCollapseVisible: boolean = false;
  creditCollapseVisible: boolean = false;
  oilCollapseVisible: boolean = false;
  evtotalCollapseVisible: boolean = false;

  ////// toggleCollapse ////

  toggleCoinCollapse() {
    this.coinCollapseVisible = !this.coinCollapseVisible;
  }

  toggleCashCollapse() {
    this.cashCollapseVisible = !this.cashCollapseVisible;
    // if (this.cashList.length > 0) {
    //   this.cashCollapseVisible = !this.cashCollapseVisible;
    // } else {
    //   this.cashCollapseVisible = false; // always force closed if no data
    // }
  }
  toggleCreditCollapse() {
    this.creditCollapseVisible = !this.creditCollapseVisible;
  }
  toggleOilCollapse() {
    this.oilCollapseVisible = !this.oilCollapseVisible;
  }

  toggleEvtotalCollapse() {
    this.evtotalCollapseVisible = !this.evtotalCollapseVisible;
  }

  preventDecimal(event: KeyboardEvent) {
    const invalidChars = ['.', ',', 'e', 'E', '+', '-'];
    if (invalidChars.includes(event.key)) {
      event.preventDefault();
    }
  }

  updateCoinTotal() {
    this.coinData.forEach(item => {
      item.count = Math.floor(Number(item.count) || 0); // only integers
      item.total = item.coins * item.count;
    });

    this.coinGrandTotal = this.coinData.reduce(
      (sum, item) => sum + item.total,
      0
    );

    this.shiftA.entries[0].shiftcoins = Math.floor(this.coinGrandTotal);

    this.calculateTotals();
  }


  updateCashTotal() {
    this.cashGrandTotal = this.cashList.reduce(
      (sum, item) => {
        item.count = Math.floor(Number(item.count) || 0); // force integer count
        item.total = item.cash * item.count;              // update row total
        return sum + item.total;
      },
      0
    );

    this.shiftA.entries[0].shiftcash = Math.floor(this.cashGrandTotal);

    this.calculateTotals();
  }

   addCustomer(): void {
  if (this.creditCustomers.length === 0 || this.creditCustomers.length > 0) {
    this.creditCustomers.push({
      vehicle: '',
      slip_no: '',
      category: 'HSD',
      customer_id: null,
      liters: 0,
      customertotal: 0,
      maxLimit: undefined,
      exceedsLimit: false
    });

    this.validateFields = true;
    return;
  }

  const hasInvalid = this.creditCustomers.some(
    c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
  );

  if (hasInvalid) {
    this.validateFields = true;
    return; 
  }

  this.validateFields = false;

  this.creditCustomers.push({
    vehicle: '',
    slip_no: '',
    category: 'HSD',
    customer_id: null,
    liters: 0,
    customertotal: 0,
    maxLimit: undefined,
    exceedsLimit: false
  });
}
checkValidationStatus(): void {
  const hasInvalid = this.creditCustomers.some(
    c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
  );

  this.validateFields = hasInvalid;
}
  // Remove row
  // removeCust(index: number): void {
  //   this.creditCustomers.splice(index, 1);
  //   if (this.creditCustomers.length > 0) {
  //     this.updateCreditTotal();
  //   } else {
  //     this.shiftA.entries[0].shiftcredit = 0;
  //   }
  // }

    removeCust(index: number): void {
  this.creditCustomers.splice(index, 1);
  const hasInvalid = this.creditCustomers.some(
    c => !c.vehicle?.trim() || !c.slip_no?.toString().trim()
  );

  this.validateFields = hasInvalid;
  if (this.creditCustomers.length === 0) {
    this.validateFields = false;
  }
}

  // Customer dropdown change
  // onCustomersChange(selectedCustomer: any, index: number) {
  //   const cust = this.creditCustomers[index];
  //   cust.customer_id = selectedCustomer?.id ?? null;
  //   cust.customer_name = selectedCustomer?.name ?? null;
  //   cust.selectedCustomer = selectedCustomer ?? null;
  // }
   onCustomersChange(selectedCustomer: any, index: number) {
    // Ensure the object exists
    if (!selectedCustomer) {
      // Clear the customer at the given index
      this.creditCustomers[index] = {
        customer_id: null,
        customer_name: null,
        selectedCustomer: null,
        category: 'HSD',
        liters: 0,
        vehicle: '',
        slip_no:'',
        customertotal: 0,
        maxLimit: 0,
        exceedsLimit: false,
        within_terms: true,
        allowed_credit: true
      };
      return; // Early exit if no customer is selected
    }
    if (!this.creditCustomers[index]) {
      this.creditCustomers[index] = {
        customer_id: null,
        customer_name: null,
        selectedCustomer: null,
        category: 'HSD',
        liters: 0,
        vehicle: '',
        slip_no:'',
        customertotal: 0,
        maxLimit: 0,
        exceedsLimit: false,
        within_terms: true,
        allowed_credit: true
      };
    }

    const cust = this.creditCustomers[index];

    cust.customer_id = selectedCustomer?.id ?? null;
    cust.customer_name = selectedCustomer?.name ?? null;
    cust.selectedCustomer = selectedCustomer ?? null;
    // cust.maxLimit = Number(selectedCustomer.credit_limit);
    console.log('Updated customer:', cust);
    this.getEligibleCustomers(cust.customer_id);
    //this.updateCustomerTotal(index);
  }
  getEligibleCustomers(customerId: number | null) {
    const user_id = localStorage.getItem('user_id');
    if (!customerId) {
      console.log("No valid customer ID found.");
      return;
    }

    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "getEligibleCustomers",
      user_id: user_id,
      customer_id: customerId.toString()
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        console.log('API Response:', response);
        if (response.data) {
          const data = response.data;
          const cust = this.creditCustomers.find(c => c.customer_id === data.id);

          if (cust) {
            cust.customer_name = data.name;
            cust.maxLimit = Number(data.credit_limit);
            cust.within_terms = data.within_terms;
            cust.allowed_credit = data.allowed_credit;

            cust.exceedsLimit = !data.within_terms || !data.allowed_credit;
            this.updateCustomerRow(this.creditCustomers.indexOf(cust));
          }
        }
      },
      error: (err) => {
        console.error('Error fetching customer data:', err);
      }
    });
  }

  // Search dropdown
  onCustSearchChange(event: any): void {
    this.keyword = event.term;
    this.getCustomer(this.keyword);
  }

  // Recalculate one row + grand total
  updateCustomerRow(i: number) {
    const cust = this.creditCustomers[i];

    const liters = Number(cust.liters) || 0;
    const rate = this.getFuelRate(cust.category); // get from MS/HSD price
    cust.rate = rate;
    cust.customertotal = liters * rate;

    this.updateCreditTotal();
  }

  // Get fuel rate (from your shiftA.entries data)
  getFuelRate(category: string): number {
    if (category === 'MS') {
      return this.shiftA.entries[0].ms_price || 0;
    }
    if (category === 'HSD') {
      return this.shiftA.entries[0].hsd_price || 0;
    }
    return 0;
  }

  // Grand total
  updateCreditTotal() {
    const total = this.creditCustomers.reduce((sum, c) => sum + (c.customertotal || 0), 0);
    this.shiftA.entries[0].shiftcredit = parseFloat(total.toFixed(2));
    this.calculateTotals();
  }


  updateProductTotals(p: any) {
    p.quantity = Number(p.quantity || 0);
    p.price = Number(p.price || 0);

    p.total_ml = p.quantity * p.price;
    p.liters = parseFloat((p.total_ml / 1000).toFixed(2));

    // ✅ sum of all products
    const total = this.products.reduce((sum, pr) => sum + (pr.total_ml || 0), 0);
    this.shiftA.entries[0].shiftoilsales = parseFloat(total.toFixed(2));

    this.calculateTotals();
  }

  updateEvTotal() {
    const ev = this.shiftA.entries[0].ev_entry[0];

    const hours = Number(ev.ev_hours) || 0;
    const rate = Number(ev.rate) || 0;

    ev.total = parseFloat((hours * rate).toFixed(2));

    // also store in main entry for "Ev Total"
    this.shiftA.entries[0].shifevtotal = ev.total;
    this.calculateTotals();
  }

  updateMSSales(index: number) {
    const entry = this.shiftA.entries[index];

    const opening = Number(entry.ms_opening_reading) || 0;
    const closing = Number(entry.ms_closing_reading) || 0;
    const price = Number(entry.ms_price) || 0;
    const testLiters = Number(entry.ms_test_liters) || 0;

    entry.ms_total_sales = closing - opening;
    entry.ms_test_amount = parseFloat((testLiters * price).toFixed(2));
    entry.ms_total_amount = parseFloat(((entry.ms_total_sales * price) - entry.ms_test_amount).toFixed(2));
    this.calculateTotals();
  }

  updateHSDSales(index: number) {
    const entry = this.shiftA.entries[index];

    const opening = Number(entry.hsd_opening_reading) || 0;
    const closing = Number(entry.hsd_closing_reading) || 0;
    const price = Number(entry.hsd_price) || 0;
    const testLiters = Number(entry.hsd_test_liters) || 0;

    entry.hsd_total_sales = closing - opening;
    entry.hsd_test_amount = parseFloat((testLiters * price).toFixed(2));
    entry.hsd_total_amount = parseFloat(((entry.ms_total_sales * price) - entry.hsd_test_amount).toFixed(2));
    this.calculateTotals();
  }


  calculateTotals() {
    const entry = this.shiftA.entries[0];
    const num = (val: any) => parseFloat(val) || 0;

    // 1. Total (coins + gpay + phonepe + swiping + cash + credit)
    entry.shifttotal =
      num(entry.shiftcoins) +
      num(entry.shiftgpay) +
      num(entry.shiftphonepe) +
      num(entry.shiftswiping) +
      num(entry.shiftcash) +
      num(entry.shiftcredit);
    // 2. Grand Total (Total - Receipt)
    entry.shiftgrandtotal = num(entry.shifttotal) - num(entry.shiftreceipt);
    // 3. Fuel Total (MS + HSD)
    entry.shiftfueltotal =
      num(entry.ms_total_amount) + num(entry.hsd_total_amount);
    // 4. GTotal (fuel + oil + ev - discount + extra fuel)
    entry.shiftgtotal =
      num(entry.shiftfueltotal) +
      num(entry.shiftoilsales) +
      num(entry.shifevtotal) -
      num(entry.shiftdiscount) -
      num(entry.shiftextrafuel);

    // 5. Difference (Total - GTotal)
    entry.shiftdifference = num(entry.shiftgrandtotal) - num(entry.shiftgtotal);

    // ✅ Round everything to 2 decimals
    entry.shifttotal = +entry.shifttotal.toFixed(2);
    entry.shiftgrandtotal = +entry.shiftgrandtotal.toFixed(2);
    entry.shiftfueltotal = +entry.shiftfueltotal.toFixed(2);
    entry.shiftgtotal = +entry.shiftgtotal.toFixed(2);
    entry.shiftdifference = +entry.shiftdifference.toFixed(2);
  }


  getCaseCoinType() {
    const requestData = { api_url: 'get_cashCoinTypes' };
    this.serverService.sendServerGet(requestData).subscribe({
      next: (response: any) => {
        if (response.status == 'true' || response.status == true) {


          this.allOilProducts = response.products.map((p: any) => ({
            product_id: p.id,
            product_name: p.name,
            quantity: 0,
            price: parseFloat(p.price),
            total_ml: 0,
            liters: 0
          }));
          console.log('this.products', this.products);

        }
      },
      error: (err) => console.error('❌ Network/API error', err)
    });
  }
  editShiftEntry(id: any) {
    this.isLoading = true;
    const requestData = {
      api_url: 'shiftEntryEdit',
      id: id
    };

    this.serverService.sendService2(requestData).subscribe({
      next: (response: any) => {
        if (response.status === true || response.status === 'true') {
          const data = response.data;

          // Convert dd-MM-yyyy → yyyy-MM-dd
          let formattedDate = '';
          if (data.shift_date) {
            const [dd, mm, yyyy] = data.shift_date.split('-');
            formattedDate = `${yyyy}-${mm}-${dd}`;
          }

          // Patch API data into shiftA.entries[0]
          this.shiftA.entries[0] = {
            ...this.shiftA.entries[0], // keep defaults
            shiftDate: formattedDate,
            pump: data.pump_no || '',
            shift: data.shift || '',
            operatorId: Number(data.operator_id) || 0,
            operatorName: data.operator_name || '',
            price: Number(data.price) || 0,

            // 🔹 MS fields (Petrol)
            ms_fuel_type: data.ms_fuel_type || 'MS',
            ms_opening_reading: Number(data.ms_opening_reading) || 0,
            ms_closing_reading: Number(data.ms_closing_reading) || 0,
            ms_total_sales: Number(data.ms_total_sales) || 0,
            ms_price: Number(data.ms_price) || 0,
            ms_test_liters: Number(data.ms_test_liters) || 0,
            ms_test_amount: Number(data.ms_test_amount) || 0,
            ms_total_amount: Number(data.ms_total_amount) || 0,

            // 🔹 HSD fields (Diesel)
            hsd_fuel_type: data.hsd_fuel_type || 'HSD',
            hsd_opening_reading: Number(data.hsd_opening_reading) || 0,
            hsd_closing_reading: Number(data.hsd_closing_reading) || 0,
            hsd_total_sales: Number(data.hsd_total_sales) || 0,
            hsd_price: Number(data.hsd_price) || 0,
            hsd_test_liters: Number(data.hsd_test_liters) || 0,
            hsd_test_amount: Number(data.hsd_test_amount) || 0,
            hsd_total_amount: Number(data.hsd_total_amount) || 0,

            shiftcoins: Number(data.coins) || 0,
            shiftgpay: Number(data.gpay) || 0,
            shiftphonepe: Number(data.phonepe) || 0,
            shiftswiping: Number(data.swipping) || 0,
            shiftcash: Number(data.cash) || 0,
            shiftcredit: Number(data.credit) || 0,
            shifttotal: Number(data.payment_total) || 0,
            shiftreceipt: Number(data.receipt) || 0,
            shiftgrandtotal: Number(data.grand_total_1) || 0,

            shiftfueltotal: Number(data.shift_fuel_total) || 0,
            shiftoilsales: Number(data.oil_sale) || 0,
            shifevtotal: Number(data.ev_total) || 0,
            shiftdiscount: Number(data.discount) || 0,
            shiftextrafuel: Number(data.extra_fuel) || 0,
            shiftgtotal: Number(data.grand_total_2) || 0,
            shiftdifference: Number(data.difference) || 0,
            shiftmanualdifference: Number(data.manual_difference) || 0,
          };


          // coin
          this.coinData = data.coins_types.map((c: any) => ({
            id: c.id,
            coins: c.denomination,
            count: c.quantity,
            total: c.total
          }));

          const hasCoin = this.coinData.some(c => c.count > 0);
          this.coinCollapseVisible = hasCoin;


          // cash
          this.cashList = data.cash_types.map((c: any) => ({
            id: c.id,
            cash: c.denomination,
            count: c.quantity,
            total: c.total
          }));
          const hasCash = this.cashList.some(c => c.count > 0);
          this.cashCollapseVisible = hasCash;

          // credit
          this.creditCustomers = data.customer_credit.map((c: any) => ({
            id: c.id,
            shift_entry_id: c.shift_entry_id,
            customer_id: c.customer_id,
            customer_name: c.customer_name,
            selectedCustomer: { id: c.customer_id, name: c.customer_name },
            category: c.fuel_type,
            vehicle: c.vehicle_number,
            slip_no:c.slip_no,
            liters: Number(c.liters) || 0,
            rate: Number(c.rate) || 0,
            customertotal: Number(c.total) || 0,
            maxLimit: Number(c.credit_limit ?? 0),
            exceedsLimit: false,      
            within_terms: true,       
            allowed_credit: true 
          }));
          this.creditCollapseVisible = this.creditCustomers.length > 0;


          // Oil Product

          const oilChildren = data.oil_product_children || [];
          this.products = this.allOilProducts.map((base: any) => {
            const match = oilChildren.find((c: any) => c.product_name === base.product_name);
            return match
              ? {
                ...base,
                id: match.id,
                quantity: Number(match.quantity),
                price: Number(match.price),
                total_ml: Number(match.total_ml),
                liters: parseFloat(Number(match.liters).toFixed(2))
              }
              : { ...base };
          });

          this.shiftA.entries[0].shiftoilsales = parseFloat(
            this.products.reduce((sum, p) => sum + (p.total_ml || 0), 0).toFixed(2)
          );

          this.oilCollapseVisible = this.products.length > 0;


          // EV Entry
          this.shiftA.entries[0].ev_entry = (response.data.ev_entries && response.data.ev_entries.length > 0) ? response.data.ev_entries : [{ ev_hours: 0, rate: 0, total: 0 }];
          this.shiftA.entries[0].shifevtotal = Number(this.shiftA.entries[0].ev_entry[0].total) || 0;

          this.evtotalCollapseVisible = this.shiftA.entries[0].ev_entry.some(ev => ev.ev_hours > 0 || ev.rate > 0);

          this.updateCoinTotal();
          this.updateCashTotal();
          this.updateCreditTotal();
          this.getCustomer();

          this.shiftEntryName = data.shift;
          this.shiftEntryId = data.id;
          this.calculateTotals();

          const entry = this.shiftA.entries[0];
          if (entry) {
            entry.errors = {}; // reset errors
          }

          $('#editModal').modal('show');
          this.isLoading = false;
          // this.validateFields = false;
        } else {
          console.error('Failed to fetch shift entry', response.message);
          this.isLoading = false;
          // this.validateFields = false;
        }
      },
      error: (err) => {
        console.error('Network/API error', err);
        this.isLoading = false;
      }
    });
  }

  getCustomer(keyword: string = ''): void {
    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'get_customer',
      user_id: user_id,
      keyword: keyword,
    };
    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        // Check if the response contains the operator list and assign it to operators
        if (response && response.customer_list) {
          this.customerOptions = response.customer_list.map((cust: any) => ({
            id: cust.cusId,
            name: cust.customername,
            category: 'HSD',
            liters: 0,
            customertotal: 0
          }));
        }
      },
      error: (err) => {
        console.error('Error fetching operators:', err);
      }
    });
  }

  validateShift(shift: any): boolean {
    const entry = shift.entries[0]; // MS
    const entry1 = shift.entries.length > 1 ? shift.entries[1] : null;

    if (entry) entry.errors = {};
    if (entry1) entry1.errors = {};

    let isValid = true;

    // top Row validations
    if (entry && !entry.shiftDate) {
      entry.errors['shiftDate'] = 'Date is required';
      isValid = false;
    }
    if (entry && !entry.pump) {
      entry.errors['pump'] = 'Pump is required';
      isValid = false;
    }
    if (entry && !entry.shift) {
      entry.errors['shift'] = 'Shift is required';
      isValid = false;
    }
    if (entry && !entry.operatorId) {
      entry.errors['operatorId'] = 'Operator is required';
      isValid = false;
    }

    // MS validation
    if (entry && (!entry.ms_opening_reading || isNaN(entry.ms_opening_reading))) {
      entry.errors['opening'] = 'Opening is required';
      isValid = false;
    }
    if (entry && (!entry.ms_closing_reading || isNaN(entry.ms_closing_reading))) {
      entry.errors['closing'] = 'Closing is required';
      isValid = false;
    }
    // if (entry && (!entry.ms_total_sales || isNaN(entry.ms_total_sales))) {
    //   entry.errors['sales'] = 'Sales is required';
    //   isValid = false;
    // }

    // HSD validation
    if (entry1 && (!entry1.hsd_opening_reading || isNaN(entry1.hsd_opening_reading))) {
      entry1.errors['opening'] = 'Opening is required';
      isValid = false;
    }
    if (entry1 && (!entry1.hsd_closing_reading || isNaN(entry1.hsd_closing_reading))) {
      entry1.errors['closing'] = 'Closing is required';
      isValid = false;
    }
    // if (entry1 && (!entry1.hsd_total_sales || isNaN(entry1.hsd_total_sales))) {
    //   entry1.errors['sales'] = 'Sales is required';
    //   isValid = false;
    // }

    return isValid;
  }

 get hasAnyExceededLimit(): boolean {
    return this.creditCustomers.some(c =>
      c.selectedCustomer && (!c.within_terms || !c.allowed_credit)
    );
  }

  UpdateEntry(shift: any) {
    this.isLoading = true;
    const isValid = this.validateShift(shift);

    if (!isValid) {
      console.warn(`${this.shiftEntryName} form is invalid.`);
      this.isLoading = false;
      return false;
    }
    
     if (this.hasAnyExceededLimit) {
      iziToast.error({
        message: 'Some customers exceeded their credit limit or are not allowed credit.',
        position: 'topRight'
      });
      this.isLoading = false;
      return;
    }

    const entry = this.shiftA.entries[0];

    // if (entry.shiftdifference != 0) {

    //   iziToast.error({
    //     message: `${this.shiftEntryName} cannot be posted. Difference must be 0.`,
    //     position: 'topRight'
    //   });
    //   this.isLoading = false;
    //   return false;

    // }

    const requestData = {
      moduleType: "shift_entry",
      api_url: "shiftEntryUpdate",
      api_type: "api",
      user_id: "1",   // replace with logged-in user id
      id: this.shiftEntryId, // keep entry id if available

      shift_entry: {
        // Top fields
        shift_date: entry.shiftDate,
        shift: entry.shift,
        pump_no: entry.pump,
        operator_id: entry.operatorId,
        operator_name: entry.operatorName,

        // table Totals
        shift_fuel_total: entry.shiftfueltotal || 0,
        test_fuel: entry.testfuel || 0,
        oil_sale: entry.shiftoilsales || 0,
        discount: entry.shiftdiscount || 0,
        extra_fuel: entry.shiftextrafuel || 0,

        // payment fields
        coins: entry.shiftcoins || 0,
        gpay: entry.shiftgpay || 0,
        phonepe: entry.shiftphonepe || 0,
        swipping: entry.shiftswiping || 0,
        cash: entry.shiftcash || 0,
        credit: entry.shiftcredit || 0,
        payment_total: entry.shifttotal || 0,

        receipt: entry.shiftreceipt || 0,
        grand_total_1: entry.shiftgrandtotal || 0,
        grand_total_2: entry.shiftgtotal || 0,
        difference: entry.shiftdifference || 0,
        manual_difference: entry.shiftmanualdifference || 0,
        ev_total: entry.shifevtotal || 0,

        // Denominations
        coins_denom: this.coinData.map(c => ({
          denomination: c.coins,
          quantity: c.count,
          total: c.total
        })),

        cash_denom: this.cashList.map(c => ({
          denomination: c.cash,
          quantity: c.count,
          total: c.total
        })),

        // Oil products
        product_entry: this.products.map(p => ({
          product_name: p.product_name,
          product_id: p.product_id || 0,
          quantity: p.quantity,
          price: p.price,
          total_ml: p.total_ml,
          liters: p.liters
        })),

        // Credit customers
        customer_credit: this.creditCustomers.map(c => ({
          customer_id: c.customer_id,
          customer_name: c.customer_name,
          fuel_type: c.category,
          vehicle_number: c.vehicle,
          slip_no:c.slip_no,
          liters: c.liters,
          rate: c.rate,
          total: c.customertotal
        })),

        // EV entries
        ev_entry: entry.ev_entry.map(e => ({
          ev_hours: e.ev_hours,
          rate: e.rate,
          total: e.total
        })),

        // MS (Petrol)
        ms_fuel_type: entry.ms_fuel_type,
        ms_opening_reading: entry.ms_opening_reading,
        ms_closing_reading: entry.ms_closing_reading,
        ms_total_sales: entry.ms_total_sales,
        ms_price: entry.ms_price,
        ms_test_liters: entry.ms_test_liters,
        ms_test_amount: entry.ms_test_amount,
        ms_total_amount: entry.ms_total_amount,

        // HSD (Diesel)
        hsd_fuel_type: entry.hsd_fuel_type,
        hsd_opening_reading: entry.hsd_opening_reading,
        hsd_closing_reading: entry.hsd_closing_reading,
        hsd_total_sales: entry.hsd_total_sales,
        hsd_price: entry.hsd_price,
        hsd_test_liters: entry.hsd_test_liters,
        hsd_test_amount: entry.hsd_test_amount,
        hsd_total_amount: entry.hsd_total_amount
      }
    };

    // return false;

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        if (response.status === true || response.status === "true") {

          iziToast.success({
            message: response.message,
            position: 'topRight'
          });

          $('#editModal').modal('hide');
          this.isLoading = false;
        } else {

          iziToast.error({
            message: response.message,
            position: 'topRight'
          });
          this.isLoading = false;
        }
      },
      error: (err) => {
        console.error("Update error:", err);
        this.isLoading = false;
      }
    });

    return true;

  }

  ////////////////////////////////////////////////////////////////  edit ends /////////////////////////////////////////////////////////////
  deleteShiftEntry(id: any) {

    const requestData = {
      api_url: 'shiftEntryDelete',
      id: id
    }

    Swal.fire({
      title: 'Are you sure?',
      text: `You are about to delete. This action cannot be undone!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel'
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire({ title: 'Deleting...', allowOutsideClick: false });
        Swal.showLoading();

        this.serverService.sendService2(requestData).subscribe({
          next: (response: any) => {
            Swal.close();

            if (response.status == 'true' || response.status == true) {
              this.shiftEntryListData();
              iziToast.success({
                message: response.message,
                position: 'topRight'
              });

              // Swal.fire('Deleted!', 'Shift entry has been deleted.', 'success');

            } else {
              Swal.fire('Failed!', response.message || 'Delete failed', 'error');
            }
          },
          error: (err) => {
            Swal.close();
            Swal.fire('Error!', 'Network error occurred', 'error');
          }
        });
      }
    });


  }


  viewShiftEntry(id: any) {
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'shiftEntryEdit',
      user_id: '1',
      id: id
    };

    this.serverService.sendServerGetID(requestData).subscribe({
      next: (response: any) => {
        if (response.status === true || response.status === 'true') {
          const entry = response.data;
          this.viewData = {
            ...entry,
            cash_denom: entry.cash_types || [],
            coins_denom: entry.coins_types || [],
            product_entry: entry.oil_product_children || [],
            ev_entry: entry.ev_entries || [],
            customer_credit: entry.customer_credit || []
          };

          $('#viewModal').modal('show');
          this.isLoading = false;
        }
      },
      error: (err) => {
        console.error('❌ View API error', err);
        this.isLoading = false;
      }
    });
  }
  closeModal(): void {
    const entry = this.shiftA.entries[0];
    if (entry) {
      entry.errors = {}; // reset errors
    }
    $('#editModal').modal('hide');
    $('#viewModal').modal('hide');
    $('#overAllViewModal').modal('hide');
  }

  pdfShiftEntry(shiftId: number) {
    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "shiftreportPdf",
      user_id: "1",
      from_date: "",
      to_date: "",
      nozzle: "",
      shift_no: "",
      id: shiftId
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        if (response.status && response.pdf_url) {
          window.open(response.pdf_url, "_blank");
        } else {
          console.error("PDF URL not found in response", response);
        }
      },
      error: (err) => {
        console.error("PDF request failed:", err);
      }
    });
  }
  pdfShiftEntry1() {

    var formDate = $('#filterfromDate').val();
    var toDate = $('#filterToDate').val();
    var shiftNo = $('#filterShift').val();
    var operatorId = this.shiftA.entries[0].operatorId == 0 ? '' : this.shiftA.entries[0].operatorId;
    var fuleType = $('#filterFuel').val();
    var pumpNo = $('#filterPump').val();
    const requestData = {
      moduleType: "shift_entry",
      api_type: "api",
      api_url: "shiftreportPdf",
      user_id: "1",
      from_date: formDate,
      to_date: toDate,
      nozzle: pumpNo,
      shift_no: shiftNo,
      fuel_type: fuleType,
      operator_name: operatorId,
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        if (response.status && response.pdf_url) {
          window.open(response.pdf_url, "_blank");
        } else {
          console.error("PDF URL not found in response", response);
        }
      },
      error: (err) => {
        console.error("PDF request failed:", err);
      }
    });
  }

  filterByDate1() {
    this.isLoading = true;
    const user_id = localStorage.getItem('user_id');
    if (!this.fromDate) {
      this.isLoading = false;

      iziToast.error({
        title: 'Error',
        message: 'Please select a date before filtering.',
        position: 'topRight'
      });

      return;
    }
    //const formattedDate = this.selectedDate;
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'shiftSummary',
      user_id: user_id,
      from_date: this.fromDate,
      to_date: this.toDate
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        if (response.status) {
          this.isLoading = false;
          const summary = response.summary;

          const normalizeFuelList = (fuelList: any[]): any[] => {
            if (fuelList.length && fuelList[0].date) {
              return fuelList;
            }
            return [
              {
                date: summary.date || '',
                shifts: fuelList
              }
            ];
          };

          const fuel_list = Array.isArray(summary.fuel_list)
            ? normalizeFuelList(summary.fuel_list).flatMap((day: any) =>
              day.shifts?.flatMap((shift: any) => {
                return ['MS', 'HSD'].flatMap(fuelType => {
                  let opening = 0, closing = 0, sales_qty = 0, test_liters = 0, test_amount = 0, total = 0, price = 0;

                  // Iterate through pumps and aggregate fuel data
                  return shift.pumps?.map((pump: any) => {
                    const fuel = pump[fuelType];
                    if (fuel) {
                      opening += parseFloat(fuel.opening_reading) || 0;
                      closing += parseFloat(fuel.closing_reading) || 0;
                      sales_qty += parseFloat(fuel.total_sales) || 0;
                      test_liters += parseFloat(fuel.test_liters) || 0;
                      test_amount += parseFloat(fuel.test_amount) || 0;
                      total += parseFloat(fuel.total_amount) || 0;
                      price = parseFloat(fuel.price) || 0;
                    }

                    // Return data per fuel type and pump_no
                    return {
                      fuel_type: fuelType,
                      shift: shift.shift,
                      pump_no: pump.pump_no,
                      date: day.date,
                      opening: opening.toFixed(2),
                      closing: closing.toFixed(2),
                      sales_qty: sales_qty.toFixed(2),
                      test_liters: test_liters.toFixed(2),
                      test_amount: test_amount.toFixed(2),
                      total: total.toFixed(2),
                      price: price.toFixed(2),
                    };
                  });
                });
              })
            )
            : [];
          const table = $('#filterdatatable').DataTable();
          table.destroy();

          setTimeout(() => {
            $('#filterdatatable').DataTable();
          }, 0);
          this.viewData = {
            shift_date: response.date,

            // fuel_list: [
            //   {
            //     fuel_type: 'MS',
            //     opening: summary.fuel_list.MS.ms_opening_reading,
            //     closing: summary.fuel_list.MS.ms_closing_reading,
            //     sales_qty: summary.fuel_list.MS.ms_total_sales,
            //     price: summary.fuel_list.MS.ms_price,
            //     test_amount: summary.fuel_list.MS.ms_test_amount,
            //     test_liters: summary.fuel_list.MS.ms_test_liters,
            //     total: summary.fuel_list.MS.ms_total_amount
            //   },
            //   {
            //     fuel_type: 'HSD',
            //     opening: summary.fuel_list.HSD.hsd_opening_reading,
            //     closing: summary.fuel_list.HSD.hsd_closing_reading,
            //     sales_qty: summary.fuel_list.HSD.hsd_total_sales,
            //     price: summary.fuel_list.HSD.hsd_price,
            //     test_amount: summary.fuel_list.HSD.hsd_test_amount,
            //     test_liters: summary.fuel_list.HSD.hsd_test_liters,
            //     total: summary.fuel_list.HSD.hsd_total_amount
            //   }
            // ],
            fuel_list: fuel_list,
            coins: summary.coins_total,
            coins_denom: summary.coin_denominations,

            gpay: summary.gpay_total,
            phonepe: summary.phonepe_total,
            swipping: summary.swipping_total,
            cash: summary.cash_total,
            cash_denom: summary.cash_denominations,
            customer_credits: summary.customer_credits,
            credit: summary.credit_total,
            payment_total: summary.payment_total,
            receipt: summary.receipt_total,
            grand_total_1: summary.grand_total_1,

            shift_fuel_total: summary.fuel_sales_total,
            test: summary.test_fuel,
            oil_sale: summary.oil_sales_total,
            product_entry: summary.oil_products,
            ev_total: summary.ev_total,
            ev_entry: summary.ev_summary,
            discount: summary.discount,
            extra_fuel: summary.extra_fuel,
            grand_total_2: summary.grand_total_2,
            difference: summary.difference_total,
            manual_difference: summary.manual_difference_total
          };
          $('#overAllViewModal').modal('show');
          this.isLoading = false;
          this.fromDate = '';
          this.toDate = '';
        } else {
          iziToast.warning({
            title: 'No Data',
            message: 'No summary data found for the selected date.',
            position: 'topRight'
          });
          this.isLoading = false;
          this.fromDate = '';
          this.toDate = '';
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('❌ View API error', err);
      }
    });
  }

    filterByDate() {
    this.isLoading = true;
    const user_id = localStorage.getItem('user_id');

    if (!this.fromDate) {
      this.isLoading = false;
      iziToast.error({
        title: 'Error',
        message: 'Please select a date before filtering.',
        position: 'topRight'
      });
      return;
    }

    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'shiftSummary',
      user_id,
      from_date: this.fromDate,
      to_date: this.toDate
    };

    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        if (response.status) {
          const summary = response.summary;
          let fuel_list: any[] = [];

            if (Array.isArray(summary.fuel_summary)) {
            // 🚀 Case 1: Check if it’s shift-wise (shift + pumps)
            if (summary.fuel_summary.length && summary.fuel_summary[0].pumps) {
              fuel_list = summary.fuel_summary.flatMap((shift: any) =>
                shift.pumps.flatMap((pump: any) =>
                  ['MS', 'HSD'].map(fuelType => {
                    const fuel = pump[fuelType][0];
                    return {
                      shift: shift.shift,
                      pump_no: pump.pump_no,
                      fuel_type: fuelType,
                      opening: fuel.opening_reading,
                      closing: fuel.closing_reading,
                      sales_qty: fuel.total_sales,
                      test_liters: fuel.test_liters,
                      test_amount: fuel.test_amount,
                      total: fuel.total_amount

                    };
                  })
                )
              );

            } else {
              // 🚀 Case 2: Pump-wise (no shift, just pumps array)
              fuel_list = summary.fuel_summary.flatMap((pump: any) =>
                ['MS', 'HSD'].flatMap(fuelType => {
                  const fuels = pump[fuelType] || [];
                  return fuels.map((fuel: any) => ({
                    shift: '-',
                    pump_no: pump.pump_no,
                    fuel_type: fuelType,
                    opening: fuel.opening_reading,
                    closing: fuel.closing_reading,
                    sales_qty: fuel.total_sales,
                    test_liters: fuel.test_liters,
                    test_amount: fuel.test_amount,
                    total: fuel.total_amount
                  }));
                })
              );
            }

          } else {
            // 🚀 Case 3: Totals only (single object with MS/HSD)
            fuel_list = ['MS', 'HSD'].map(fuelType => {
              const fuel = summary.fuel_summary[fuelType];
              return {
                shift: '-',
                pump_no: '-',
                fuel_type: fuelType,
                opening: fuel.opening_reading,
                closing: fuel.closing_reading,
                sales_qty: fuel.total_sales,
                test_liters: fuel.test_liters,
                test_amount: fuel.test_amount,
                total: fuel.total_amount
              };
            });
          }

          const normalize = (data: any) =>
            Array.isArray(data) ? data : (data ? Object.values(data) : []);
          this.viewData = {
            shift_date: response.date,
            fuel_list,
            coins: summary.coins_total ?? 0,
            gpay: summary.gpay_total ?? 0,
            cash: summary.cash_total ?? 0,
            coins_denom: normalize(summary.coin_denominations),
            phonepe: summary.phonepe_total ?? 0,
            swipping: summary.swipping_total ?? 0,
            cash_denom: normalize(summary.cash_denominations),
            customer_credits: normalize(summary.customer_credits),
            credit: summary.credit_total ?? 0,
            payment_total: summary.payment_total ?? 0,
            receipt: summary.receipt_total ?? 0,
            grand_total_1: summary.grand_total_1 ?? 0,

            shift_fuel_total: summary.fuel_sales_total ?? 0,
            test: summary.test_fuel ?? 0,
            oil_sale: summary.oil_sales_total ?? 0,
            product_entry: normalize(summary.oil_products),
            ev_total: summary.ev_total ?? 0,
            ev_entry: normalize(summary.ev_summary),
            discount: summary.discount ?? 0,
            extra_fuel: summary.extra_fuel ?? 0,
            grand_total_2: summary.grand_total_2 ?? 0,
            difference: summary.difference_total ?? 0,
            manual_difference: summary.manual_difference_total ?? 0,
          };

          this.hint = response.hint; // 👈 very important
          this.isLoading = false;
          $('#overAllViewModal').modal('show');
          this.fromDate = '';
          this.toDate = '';
        } else {
          iziToast.warning({
            title: 'No Data',
            message: 'No summary data found.',
            position: 'topRight'
          });
          this.isLoading = false;
          this.fromDate = '';
          this.toDate = '';
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('❌ API error', err);
        this.fromDate = '';
        this.toDate = '';
      }
    });
  }

}
